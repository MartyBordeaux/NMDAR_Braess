#!/usr/bin/env python3
"""
NMDAR Braess — Step 11 v1.1
Archive-aware experimental controls reanalysis for IV_NMDA.

This version supersedes Step 11 v1.0.

It is deliberately tailored to the verified IV_NMDA archive structure:
  ~/nmda/IV_NMDA

PRIMARY MODULE A
----------------
Acute memantine SlowEPSC paired reanalysis.

Included acute control/+mem candidates:
  02.12.2021  Cell1, Cell2
  03.12.2021  Cell1
  15.03.2022  Cell2
  22.06.2022  SlowEPSC2
  29.06.2022  unlabeled SlowEPSC cell
  26.09.2022  Cell1, Cell2

The chronic directory:
  "Мемантин 9 недель"
is EXCLUDED from the acute pharmacological comparison.

Only Slow/SlowEPSC is used for the memantine plateau analysis.
PF / PF_IV is never treated as PPF and is never mixed into SlowEPSC.

PRIMARY MODULE B
----------------
Paired-pulse PPF reanalysis.

Ro25 pairs included only when the archive contains same-cell:
  PPF+NBQX
  PPF+NBQX+Ro25
under:
  Ro25/17.10.2022/Cell1
  Ro25/17.10.2022/Cell2

Acute memantine PPF:
  22.06.2022/PPF2
  22.06.2022/PPF2+mem

Everything else is inventoried but is not silently promoted to a paired drug
comparison.

No p-values are generated. Sweeps are aggregated within cell x condition before
drug comparison. PPF is supporting/descriptive only and cannot exclude a
presynaptic contribution.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from scipy.signal import find_peaks

os.environ.setdefault("MPLBACKEND", "Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

try:
    import pyabf
except ImportError:
    pyabf = None


VERSION = "1.2.0"
DEFAULT_RAW_ROOT = Path.home() / "nmda" / "IV_NMDA"

# Frozen Ro25 train-plateau observable.
TRAIN_EXPECTED_PULSES = 25
TRAIN_INTERVAL_MS = 5.1
TRAIN_SEARCH_START_MS = 8.0
TRAIN_SEARCH_END_MS = 145.0
TRAIN_GUARD_MS = 0.8
TRAIN_DROP_FIRST = 5

NEGATIVE_VOLTAGES = [-80, -70, -60, -40, -20]

# PPF measurement settings.
PPF_ARTIFACT_GUARD_MS = 0.8
PPF_LOCAL_BASELINE_START_MS = 10.0
PPF_LOCAL_BASELINE_END_MS = 2.0
PPF_RESPONSE_MAX_MS = 40.0

CHRONIC_MEM_FOLDER = "мемантин 9 недель"


def norm(s: str) -> str:
    return s.lower().replace("\\", "/").replace("ё", "е")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def robust_sd(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return float("nan")
    med = np.median(x)
    mad = np.median(np.abs(x - med))
    return float(1.4826 * mad)


def parse_date(path: Path) -> Optional[str]:
    m = re.search(r"(?<!\d)(\d{2})\.(\d{2})\.(20\d{2})(?!\d)", str(path))
    if not m:
        return None
    d, mo, y = m.groups()
    return f"{y}-{mo}-{d}"


def parse_voltage(path: Path) -> Optional[int]:
    """Parse the signed voltage from verified IV_NMDA filename patterns.

    Supported examples include:
      slowEPSC -40Group1Series1.abf
      SlowEPSC2+mem-40Group1Series1.abf
      SlowEPSC2-40+memGroup1Series1.abf
      Slow+mem/-40Group1Series1.abf
    """
    name = path.name
    patterns = [
        r"([+-]?\d{1,3})(?=\+memGroup\d+Series\d+\.abf$)",
        r"([+-]?\d{1,3})(?=Group\d+Series\d+\.abf$)",
    ]
    for pat in patterns:
        m = re.search(pat, name, re.I)
        if m:
            v = int(m.group(1))
            if -100 <= v <= 100:
                return v
    return None


def parse_cell(path: Path) -> Optional[str]:
    # Explicit Cell folder/name first.
    s = str(path)
    m = re.search(r"(?i)\bCell\s*([0-9]+)\b", s)
    if m:
        return f"cell{int(m.group(1))}"

    # 15.03/22.06 patterns such as SlowEPSC2.
    m = re.search(r"(?i)SlowEPSC\s*([0-9]+)", path.name)
    if m:
        return f"cell{int(m.group(1))}"

    # PPF2 / PPF2+mem.
    m = re.search(r"(?i)\bPPF\s*([0-9]+)", path.name)
    if m:
        return f"cell{int(m.group(1))}"

    # 29.06 unnumbered acute SlowEPSC pair.
    date = parse_date(path)
    if date == "2022-06-29" and "slowepsc" in norm(path.name):
        return "cell_unlabeled"

    return None


def is_chronic_mem(path: Path) -> bool:
    return CHRONIC_MEM_FOLDER in norm(str(path))


def is_ro25_branch(path: Path, raw_root: Path) -> bool:
    rel = path.relative_to(raw_root)
    return len(rel.parts) > 0 and rel.parts[0].lower() == "ro25"


def is_slowepsc(path: Path) -> bool:
    s = norm(str(path))
    # PF/PPF are explicitly excluded.
    if "ppf" in s or "/pf/" in s or "pf_iv" in s or "/pf+mem/" in s:
        return False
    return "slowepsc" in s or "/slow/" in s or "/slow+mem/" in s


def has_mem_marker(path: Path) -> bool:
    s = norm(str(path))
    return (
        "+mem" in s
        or "/slow+mem/" in s
        or " +mem " in s
        or "+mem-" in s
        or "+mem+" in s
    )


def has_ro25_marker_after_date(path: Path) -> bool:
    # Root folder "Ro25" by itself does not define drug condition.
    s = norm(str(path))
    # Pairing-relevant explicit marker.
    return "+ro25" in s


def has_nbqx(path: Path) -> bool:
    return "nbqx" in norm(str(path))


def is_ppf(path: Path) -> bool:
    # Strict PPF only; PF / PF_IV excluded.
    return "ppf" in norm(path.name)


def unique_abfs(raw_root: Path) -> list[Path]:
    """
    Keep physical duplicates visible by path in the inventory; deduplication is
    not applied across conditions because path provenance matters here.
    """
    return sorted(raw_root.rglob("*.abf"))


def read_abf_sweeps(path: Path):
    if pyabf is None:
        raise RuntimeError("pyabf not installed. Run: pip install pyabf")
    abf = pyabf.ABF(str(path))
    rows = []
    for sweep in range(abf.sweepCount):
        abf.setSweep(sweep)
        t_ms = np.asarray(abf.sweepX, float) * 1000.0
        y = np.asarray(abf.sweepY, float)
        unit = str(getattr(abf, "sweepUnitsY", "")).strip()
        if unit.lower() == "pa":
            y_nA = y / 1000.0
        elif unit.lower() == "na":
            y_nA = y
        else:
            # Conservative fallback for this archive.
            p99 = np.nanpercentile(np.abs(y), 99.0)
            y_nA = y / 1000.0 if p99 > 20 else y
        rows.append((sweep, t_ms, y_nA, unit))
    return rows


def detect_train_peaks(t_ms: np.ndarray, y_bs: np.ndarray) -> np.ndarray:
    m = (t_ms >= TRAIN_SEARCH_START_MS) & (t_ms <= TRAIN_SEARCH_END_MS)
    if m.sum() < 20:
        return np.array([], float)
    tt = t_ms[m]
    yy = y_bs[m]
    dt = float(np.median(np.diff(tt)))
    min_distance = max(1, int(round(3.0 / dt)))
    noise = robust_sd(yy[(tt < 15) | (tt > 135)])
    if not np.isfinite(noise) or noise <= 0:
        noise = robust_sd(yy)
    prom = max(0.01, 6 * noise if np.isfinite(noise) else 0.01)

    idx, props = find_peaks(yy, distance=min_distance, prominence=prom)
    if len(idx) < 23:
        idx, props = find_peaks(
            yy,
            distance=min_distance,
            prominence=max(0.003, prom / 3.0),
        )
    times = tt[idx]
    if len(times) > 25:
        # choose contiguous 25-candidate block best matching 5.1 ms
        best = None
        for j in range(len(times) - 24):
            cand = times[j:j+25]
            score = float(np.median(np.abs(np.diff(cand) - TRAIN_INTERVAL_MS)))
            if best is None or score < best[0]:
                best = (score, cand)
        if best is not None:
            times = best[1]
    return np.asarray(times, float)


def plateau_metric(t_ms: np.ndarray, y_nA: np.ndarray) -> dict:
    bm = t_ms < 8.0
    if bm.sum() < 5:
        raise RuntimeError("baseline_too_short")

    baseline = float(np.median(y_nA[bm]))
    y = y_nA - baseline
    base_sd = robust_sd(y[bm])

    peaks = detect_train_peaks(t_ms, y)
    flags = []
    if len(peaks) < 23:
        flags.append("artifact_count_lt23")
    if len(peaks) < 2:
        return {
            "baseline_nA": baseline,
            "baseline_sd_nA": base_sd,
            "artifact_count": int(len(peaks)),
            "pulse_interval_median_ms": np.nan,
            "plateau_level_nA": np.nan,
            "plateau_abs_nA": np.nan,
            "negative_fraction": np.nan,
            "interval_cv": np.nan,
            "slope_nA_per_interval": np.nan,
            "qc_flags": ";".join(flags + ["cannot_extract"]),
        }

    intervals = []
    for a, b in zip(peaks[:-1], peaks[1:]):
        w = (t_ms >= a + TRAIN_GUARD_MS) & (t_ms <= b - TRAIN_GUARD_MS)
        if w.sum() >= 2:
            intervals.append(float(np.median(y[w])))

    vals = np.asarray(intervals, float)
    retained = vals[TRAIN_DROP_FIRST:]
    if len(retained) != 19:
        flags.append(f"retained_intervals_{len(retained)}")

    plateau = float(np.median(retained)) if len(retained) else np.nan
    neg_frac = float(np.mean(retained < 0)) if len(retained) else np.nan

    mag = np.abs(retained)
    cv = float(np.std(mag) / np.mean(mag)) if len(mag) and np.mean(mag) > 0 else np.nan
    if len(retained) >= 3:
        slope = float(np.polyfit(np.arange(len(retained)), retained, 1)[0])
    else:
        slope = np.nan

    if np.isfinite(neg_frac) and neg_frac < 0.70:
        flags.append("negative_fraction_low")
    if np.isfinite(cv) and cv > 0.30:
        flags.append("interval_cv_high")
    if np.isfinite(slope) and abs(slope) > 0.003:
        flags.append("plateau_drift")

    interval = float(np.median(np.diff(peaks)))
    if abs(interval - TRAIN_INTERVAL_MS) > 0.35:
        flags.append("pulse_interval_unexpected")

    return {
        "baseline_nA": baseline,
        "baseline_sd_nA": base_sd,
        "artifact_count": int(len(peaks)),
        "pulse_interval_median_ms": interval,
        "plateau_level_nA": plateau,
        "plateau_abs_nA": abs(plateau) if np.isfinite(plateau) else np.nan,
        "negative_fraction": neg_frac,
        "interval_cv": cv,
        "slope_nA_per_interval": slope,
        "qc_flags": ";".join(flags),
    }


def detect_ppf_stims(t_ms: np.ndarray, y_nA: np.ndarray) -> np.ndarray:
    # Robustly select two largest positive stimulation artifacts.
    early = t_ms < min(8.0, max(2.0, t_ms[-1] * 0.05))
    baseline = float(np.median(y_nA[early])) if early.sum() else float(np.median(y_nA[:20]))
    y = y_nA - baseline

    m = (t_ms >= 2.0) & (t_ms <= min(t_ms[-1], 500.0))
    tt = t_ms[m]
    yy = y[m]
    if len(tt) < 20:
        return np.array([], float)

    dt = float(np.median(np.diff(tt)))
    noise = robust_sd(yy[tt < min(20.0, tt[-1])])
    if not np.isfinite(noise) or noise <= 0:
        noise = robust_sd(yy)
    prom = max(0.01, 8 * noise if np.isfinite(noise) else 0.01)

    idx, props = find_peaks(
        yy,
        prominence=prom,
        distance=max(1, int(round(4.0 / dt))),
    )
    if len(idx) < 2:
        idx, props = find_peaks(
            yy,
            prominence=max(0.003, prom / 4),
            distance=max(1, int(round(3.0 / dt))),
        )
    if len(idx) < 2:
        return np.array([], float)

    prominences = props.get("prominences", np.ones(len(idx)))
    # Take a few strongest candidates then choose a plausible chronological pair.
    top = np.argsort(prominences)[-min(6, len(idx)):]
    cand = np.sort(tt[idx[top]])

    best = None
    for i in range(len(cand)):
        for j in range(i + 1, len(cand)):
            isi = cand[j] - cand[i]
            if not (5 <= isi <= 250):
                continue
            # no hard 50-ms assumption; weak preference toward a common PPF interval
            score = abs(isi - 50.0)
            if best is None or score < best[0]:
                best = (score, cand[i], cand[j])
    if best is None:
        return cand[:2]
    return np.array([best[1], best[2]], float)


def local_baseline(t_ms: np.ndarray, y: np.ndarray, stim: float) -> float:
    w = (
        (t_ms >= stim - PPF_LOCAL_BASELINE_START_MS)
        & (t_ms <= stim - PPF_LOCAL_BASELINE_END_MS)
    )
    if w.sum() < 3:
        w = (t_ms >= max(0, stim - 15.0)) & (t_ms <= stim - 1.0)
    return float(np.median(y[w])) if w.sum() else np.nan


def inward_response_amplitude(
    t_ms: np.ndarray,
    y: np.ndarray,
    stim: float,
    next_stim: Optional[float],
) -> float:
    start = stim + PPF_ARTIFACT_GUARD_MS
    stop = min(t_ms[-1], stim + PPF_RESPONSE_MAX_MS)
    if next_stim is not None:
        stop = min(stop, next_stim - PPF_ARTIFACT_GUARD_MS)
    w = (t_ms >= start) & (t_ms <= stop)
    if w.sum() < 5:
        return np.nan

    base = local_baseline(t_ms, y, stim)
    seg = y[w] - base

    # Mean of lowest 5% is less noise-sensitive than a single minimum.
    n = max(3, int(math.ceil(0.05 * len(seg))))
    low = np.partition(seg, n - 1)[:n]
    trough = float(np.mean(low))
    return max(0.0, -trough)


def ppf_metric(t_ms: np.ndarray, y_nA: np.ndarray) -> dict:
    stims = detect_ppf_stims(t_ms, y_nA)
    flags = []
    if len(stims) != 2:
        return {
            "stim1_ms": np.nan,
            "stim2_ms": np.nan,
            "isi_ms": np.nan,
            "response1_nA": np.nan,
            "response2_nA": np.nan,
            "ppr": np.nan,
            "qc_flags": "cannot_extract_two_stims",
        }

    s1, s2 = map(float, stims)
    a1 = inward_response_amplitude(t_ms, y_nA, s1, s2)
    a2 = inward_response_amplitude(t_ms, y_nA, s2, None)
    if not np.isfinite(a1) or a1 <= 0:
        flags.append("response1_invalid")
    if not np.isfinite(a2) or a2 <= 0:
        flags.append("response2_invalid")

    ppr = a2 / a1 if np.isfinite(a1) and a1 > 0 and np.isfinite(a2) else np.nan
    if np.isfinite(ppr) and (ppr < 0.1 or ppr > 10):
        flags.append("ppr_extreme")

    return {
        "stim1_ms": s1,
        "stim2_ms": s2,
        "isi_ms": s2 - s1,
        "response1_nA": a1,
        "response2_nA": a2,
        "ppr": ppr,
        "qc_flags": ";".join(flags),
    }


def build_inventory(raw_root: Path) -> pd.DataFrame:
    rows = []
    for p in unique_abfs(raw_root):
        rel = p.relative_to(raw_root)
        rows.append({
            "path": str(p),
            "relative_path": str(rel),
            "sha256": sha256(p),
            "date": parse_date(p),
            "cell_id": parse_cell(p),
            "voltage_mV": parse_voltage(p),
            "is_chronic_mem": is_chronic_mem(p),
            "is_ro25_branch": is_ro25_branch(p, raw_root),
            "is_slowepsc": is_slowepsc(p),
            "is_ppf": is_ppf(p),
            "nbqx": has_nbqx(p),
            "has_mem_marker": has_mem_marker(p),
            "has_ro25_marker": has_ro25_marker_after_date(p),
        })
    return pd.DataFrame(rows)


def acute_mem_manifest(inv: pd.DataFrame) -> pd.DataFrame:
    """
    Strict acute memantine pairing.
    Must be:
      outside Ro25 branch
      outside chronic memantine folder
      Slow/SlowEPSC
      same date + cell + voltage + NBQX status
      one control and one +mem recording
    """
    x = inv[
        (~inv.is_ro25_branch)
        & (~inv.is_chronic_mem)
        & (inv.is_slowepsc)
        & inv.date.notna()
        & inv.cell_id.notna()
        & inv.voltage_mV.notna()
    ].copy()
    x["condition"] = np.where(x.has_mem_marker, "memantine", "control")

    pairs = []
    for key, g in x.groupby(["date", "cell_id", "voltage_mV", "nbqx"], dropna=False):
        date, cell, voltage, nbqx = key
        c = g[g.condition == "control"]
        m = g[g.condition == "memantine"]
        status = "paired" if len(c) == 1 and len(m) == 1 else "not_unique_or_missing"
        pairs.append({
            "date": date,
            "cell_id": cell,
            "voltage_mV": int(voltage),
            "nbqx": bool(nbqx),
            "control_n_files": len(c),
            "memantine_n_files": len(m),
            "control_path": c.iloc[0].path if len(c) == 1 else "",
            "memantine_path": m.iloc[0].path if len(m) == 1 else "",
            "pair_status": status,
        })
    return pd.DataFrame(pairs)


def ro25_ppf_manifest(inv: pd.DataFrame) -> pd.DataFrame:
    """
    Only same-cell 17.10.2022 PPF+NBQX vs PPF+NBQX+Ro25.
    """
    x = inv[
        inv.is_ro25_branch
        & inv.is_ppf
        & inv.nbqx
        & (inv.date == "2022-10-17")
        & inv.cell_id.isin(["cell1", "cell2"])
    ].copy()
    x["condition"] = np.where(x.has_ro25_marker, "ro25", "control")

    pairs = []
    for (date, cell), g in x.groupby(["date", "cell_id"]):
        c = g[g.condition == "control"]
        r = g[g.condition == "ro25"]
        pairs.append({
            "date": date,
            "cell_id": cell,
            "control_n_files": len(c),
            "ro25_n_files": len(r),
            "control_path": c.iloc[0].path if len(c) == 1 else "",
            "ro25_path": r.iloc[0].path if len(r) == 1 else "",
            "pair_status": "paired" if len(c) == 1 and len(r) == 1 else "not_unique_or_missing",
        })
    return pd.DataFrame(pairs)


def mem_ppf_manifest(inv: pd.DataFrame) -> pd.DataFrame:
    """
    Verified acute memantine PPF pair:
      22.06.2022 PPF2 <-> PPF2+mem
    No NBQX requirement.
    """
    x = inv[
        (~inv.is_ro25_branch)
        & (~inv.is_chronic_mem)
        & inv.is_ppf
        & (inv.date == "2022-06-22")
        & (inv.cell_id == "cell2")
    ].copy()
    x["condition"] = np.where(x.has_mem_marker, "memantine", "control")
    c = x[x.condition == "control"]
    m = x[x.condition == "memantine"]

    # There may be PPF1 and other PPF files on this date; restrict basename to PPF2.
    c = c[c.path.map(lambda p: bool(re.search(r"(?i)PPF2(?!\+mem)", Path(p).name)))]
    m = m[m.path.map(lambda p: bool(re.search(r"(?i)PPF2\+mem", Path(p).name)))]

    return pd.DataFrame([{
        "date": "2022-06-22",
        "cell_id": "cell2",
        "control_n_files": len(c),
        "memantine_n_files": len(m),
        "control_path": c.iloc[0].path if len(c) == 1 else "",
        "memantine_path": m.iloc[0].path if len(m) == 1 else "",
        "pair_status": "paired" if len(c) == 1 and len(m) == 1 else "not_unique_or_missing",
    }])


def analyze_plateau_file(path: Path, date: str, cell: str, voltage: int, condition: str):
    sweep_rows = []
    for sweep, t_ms, y_nA, unit in read_abf_sweeps(path):
        try:
            met = plateau_metric(t_ms, y_nA)
            err = ""
        except Exception as e:
            met = {
                "baseline_nA": np.nan,
                "baseline_sd_nA": np.nan,
                "artifact_count": np.nan,
                "pulse_interval_median_ms": np.nan,
                "plateau_level_nA": np.nan,
                "plateau_abs_nA": np.nan,
                "negative_fraction": np.nan,
                "interval_cv": np.nan,
                "slope_nA_per_interval": np.nan,
                "qc_flags": "extraction_error",
            }
            err = str(e)

        sweep_rows.append({
            "date": date,
            "cell_id": cell,
            "voltage_mV": voltage,
            "condition": condition,
            "path": str(path),
            "sweep": sweep,
            "source_unit": unit,
            "error": err,
            **met,
        })
    return sweep_rows


def run_memantine_plateau(manifest: pd.DataFrame, out: Path):
    paired = manifest[manifest.pair_status == "paired"].copy()
    sweep_rows = []

    for r in paired.itertuples(index=False):
        sweep_rows += analyze_plateau_file(
            Path(r.control_path), r.date, r.cell_id, r.voltage_mV, "control"
        )
        sweep_rows += analyze_plateau_file(
            Path(r.memantine_path), r.date, r.cell_id, r.voltage_mV, "memantine"
        )

    sweeps = pd.DataFrame(sweep_rows)
    sweeps.to_csv(
        out / "04_memantine_plateau_sweep_metrics.csv.gz",
        index=False,
        compression="gzip",
    )

    agg_rows = []
    if len(sweeps):
        good = sweeps[np.isfinite(pd.to_numeric(sweeps.plateau_level_nA, errors="coerce"))]
        for key, g in good.groupby(["date", "cell_id", "voltage_mV", "condition"]):
            date, cell, voltage, condition = key
            vals = g.plateau_level_nA.to_numpy(float)
            agg_rows.append({
                "date": date,
                "cell_id": cell,
                "voltage_mV": int(voltage),
                "condition": condition,
                "n_sweeps": len(g),
                "plateau_level_nA": float(np.median(vals)),
                "plateau_abs_nA": float(abs(np.median(vals))),
                "n_qc_flagged_sweeps": int((g.qc_flags.fillna("") != "").sum()),
            })
    agg = pd.DataFrame(agg_rows)
    agg.to_csv(out / "05_memantine_plateau_cell_condition.csv", index=False)

    ratios = []
    if len(agg):
        for key, g in agg.groupby(["date", "cell_id", "voltage_mV"]):
            date, cell, voltage = key
            c = g[g.condition == "control"]
            m = g[g.condition == "memantine"]
            if len(c) != 1 or len(m) != 1:
                continue
            cv = float(c.iloc[0].plateau_level_nA)
            mv = float(m.iloc[0].plateau_level_nA)
            ratio = abs(mv) / abs(cv) if cv != 0 else np.nan
            ratios.append({
                "date": date,
                "cell_id": cell,
                "voltage_mV": int(voltage),
                "control_plateau_nA": cv,
                "memantine_plateau_nA": mv,
                "delta_level_nA": mv - cv,
                "r_plateau": ratio,
                "direction": (
                    "suppression" if ratio < 1
                    else "potentiation" if ratio > 1
                    else "neutral"
                ) if np.isfinite(ratio) else "unresolved",
                "control_relation": "within-cell acute control",
            })
    ratios = pd.DataFrame(ratios)
    ratios.to_csv(out / "06_memantine_paired_plateau_ratios.csv", index=False)

    minus40 = ratios[ratios.voltage_mV == -40].copy() if len(ratios) else ratios
    minus40.to_csv(out / "07_memantine_minus40_primary.csv", index=False)

    robust = []
    if len(ratios):
        for (date, cell), g in ratios.groupby(["date", "cell_id"]):
            h = g[g.voltage_mV.isin(NEGATIVE_VOLTAGES)]
            robust.append({
                "date": date,
                "cell_id": cell,
                "n_negative_voltages": len(h),
                "n_suppression": int((h.r_plateau < 1).sum()),
                "n_potentiation": int((h.r_plateau > 1).sum()),
                "median_r_plateau": float(np.median(h.r_plateau)) if len(h) else np.nan,
                "all_negative_voltages_suppressive": bool(len(h) > 0 and np.all(h.r_plateau < 1)),
            })
    robust = pd.DataFrame(robust)
    robust.to_csv(out / "08_memantine_negative_voltage_robustness.csv", index=False)

    return sweeps, agg, ratios, minus40, robust


def analyze_ppf_file(path: Path, date: str, cell: str, condition: str, analysis: str):
    rows = []
    for sweep, t_ms, y_nA, unit in read_abf_sweeps(path):
        try:
            met = ppf_metric(t_ms, y_nA)
            err = ""
        except Exception as e:
            met = {
                "stim1_ms": np.nan,
                "stim2_ms": np.nan,
                "isi_ms": np.nan,
                "response1_nA": np.nan,
                "response2_nA": np.nan,
                "ppr": np.nan,
                "qc_flags": "extraction_error",
            }
            err = str(e)
        rows.append({
            "analysis": analysis,
            "date": date,
            "cell_id": cell,
            "condition": condition,
            "path": str(path),
            "sweep": sweep,
            "source_unit": unit,
            "error": err,
            **met,
        })
    return rows


def run_ppf(ro_manifest: pd.DataFrame, mem_manifest: pd.DataFrame, out: Path):
    rows = []

    for r in ro_manifest[ro_manifest.pair_status == "paired"].itertuples(index=False):
        rows += analyze_ppf_file(
            Path(r.control_path), r.date, r.cell_id, "control", "ro25_nbqx"
        )
        rows += analyze_ppf_file(
            Path(r.ro25_path), r.date, r.cell_id, "ro25", "ro25_nbqx"
        )

    for r in mem_manifest[mem_manifest.pair_status == "paired"].itertuples(index=False):
        rows += analyze_ppf_file(
            Path(r.control_path), r.date, r.cell_id, "control", "memantine_acute"
        )
        rows += analyze_ppf_file(
            Path(r.memantine_path), r.date, r.cell_id, "memantine", "memantine_acute"
        )

    sweeps = pd.DataFrame(rows)
    sweeps.to_csv(out / "11_ppf_sweep_metrics.csv.gz", index=False, compression="gzip")

    agg_rows = []
    if len(sweeps):
        good = sweeps[np.isfinite(pd.to_numeric(sweeps.ppr, errors="coerce"))]
        for key, g in good.groupby(["analysis", "date", "cell_id", "condition"]):
            analysis, date, cell, condition = key
            pprs = g.ppr.to_numpy(float)
            agg_rows.append({
                "analysis": analysis,
                "date": date,
                "cell_id": cell,
                "condition": condition,
                "n_sweeps": len(g),
                "median_ppr": float(np.median(pprs)),
                "q25_ppr": float(np.quantile(pprs, 0.25)),
                "q75_ppr": float(np.quantile(pprs, 0.75)),
                "median_isi_ms": float(np.median(g.isi_ms.to_numpy(float))),
                "n_qc_flagged_sweeps": int((g.qc_flags.fillna("") != "").sum()),
            })
    agg = pd.DataFrame(agg_rows)
    agg.to_csv(out / "12_ppf_cell_condition.csv", index=False)

    paired_rows = []
    if len(agg):
        for key, g in agg.groupby(["analysis", "date", "cell_id"]):
            analysis, date, cell = key
            c = g[g.condition == "control"]
            if analysis == "ro25_nbqx":
                d = g[g.condition == "ro25"]
                drug_name = "ro25"
            else:
                d = g[g.condition == "memantine"]
                drug_name = "memantine"

            if len(c) != 1 or len(d) != 1:
                continue
            c0, d0 = c.iloc[0], d.iloc[0]
            paired_rows.append({
                "analysis": analysis,
                "date": date,
                "cell_id": cell,
                "drug": drug_name,
                "control_n_sweeps": int(c0.n_sweeps),
                "drug_n_sweeps": int(d0.n_sweeps),
                "control_ppr": float(c0.median_ppr),
                "drug_ppr": float(d0.median_ppr),
                "delta_ppr": float(d0.median_ppr - c0.median_ppr),
                "sweep_imbalance_ratio": float(
                    max(c0.n_sweeps, d0.n_sweeps) / max(1, min(c0.n_sweeps, d0.n_sweeps))
                ),
                "interpretation": "descriptive cell-level paired result only",
            })

    paired = pd.DataFrame(paired_rows)
    paired.to_csv(out / "13_ppf_paired_cell_results.csv", index=False)

    return sweeps, agg, paired


def ppf_audit_pdf(sweeps: pd.DataFrame, out: Path):
    if len(sweeps) == 0:
        return
    pdf_path = out / "14_ppf_qc_audit.pdf"
    with PdfPages(pdf_path) as pdf:
        for path, g in sweeps.groupby("path"):
            try:
                raw = read_abf_sweeps(Path(path))
            except Exception:
                continue
            # Up to first 6 sweeps per file.
            for sweep, t_ms, y_nA, unit in raw[:6]:
                row = g[g.sweep == sweep]
                if len(row) == 0:
                    continue
                r = row.iloc[0]

                fig, ax = plt.subplots(figsize=(8.5, 4.5))
                ax.plot(t_ms, y_nA, linewidth=1)
                if np.isfinite(r.stim1_ms):
                    ax.axvline(r.stim1_ms, linestyle="--", linewidth=1)
                if np.isfinite(r.stim2_ms):
                    ax.axvline(r.stim2_ms, linestyle="--", linewidth=1)
                ax.set_title(
                    f"{r.analysis} | {r.date} {r.cell_id} | {r.condition} | sweep {sweep}\n"
                    f"PPR={r.ppr:.3f}" if np.isfinite(r.ppr)
                    else f"{r.analysis} | {r.date} {r.cell_id} | {r.condition} | sweep {sweep}\nPPR=NA"
                )
                ax.set_xlabel("Time (ms)")
                ax.set_ylabel("Current (nA)")
                fig.tight_layout()
                pdf.savefig(fig)
                plt.close(fig)


def make_figures(minus40: pd.DataFrame, ppf_paired: pd.DataFrame, out: Path):
    fdir = out / "figures"
    fdir.mkdir(exist_ok=True)

    if len(minus40):
        fig, ax = plt.subplots(figsize=(7.0, 4.8))
        x = np.arange(len(minus40))
        ax.scatter(x, minus40.r_plateau)
        ax.axhline(1.0, linestyle="--", linewidth=1)
        ax.set_xticks(x)
        ax.set_xticklabels(
            [f"{d}\n{c}" for d, c in zip(minus40.date, minus40.cell_id)],
            rotation=45,
            ha="right",
            fontsize=8,
        )
        ax.set_ylabel("Memantine / within-cell control plateau ratio")
        fig.tight_layout()
        fig.savefig(fdir / "memantine_minus40_ratios.png", dpi=220)
        plt.close(fig)

    if len(ppf_paired):
        ro = ppf_paired[ppf_paired.analysis == "ro25_nbqx"]
        if len(ro):
            fig, ax = plt.subplots(figsize=(6.5, 4.8))
            x = np.arange(len(ro))
            for i, r in enumerate(ro.itertuples(index=False)):
                ax.plot([i-0.08, i+0.08], [r.control_ppr, r.drug_ppr], linewidth=1)
                ax.scatter([i-0.08, i+0.08], [r.control_ppr, r.drug_ppr])
            ax.set_xticks(x)
            ax.set_xticklabels(ro.cell_id)
            ax.set_ylabel("Cell-level median PPR")
            fig.tight_layout()
            fig.savefig(fdir / "ro25_nbqx_ppf_paired.png", dpi=220)
            plt.close(fig)


def decision_text(
    mem_manifest: pd.DataFrame,
    mem40: pd.DataFrame,
    mem_robust: pd.DataFrame,
    ppf_paired: pd.DataFrame,
) -> str:
    lines = [
        "# Step 11 v1.1 manuscript decision support",
        "",
        "## Acute memantine SlowEPSC",
        "",
        f"Strict paired date×cell×voltage records found: {int((mem_manifest.pair_status=='paired').sum())}.",
    ]

    if len(mem40):
        finite = mem40[np.isfinite(mem40.r_plateau)]
        lines += [
            f"-40 mV paired cell series: {len(finite)}.",
            f"Suppression (r<1): {int((finite.r_plateau < 1).sum())}.",
            f"Potentiation (r>1): {int((finite.r_plateau > 1).sum())}.",
            f"Median r_plateau: {np.median(finite.r_plateau):.4f}.",
        ]
    else:
        lines.append("No valid -40 mV ratios were extracted.")

    if len(mem_robust):
        lines += [
            "",
            "Negative-voltage robustness:",
        ]
        for r in mem_robust.itertuples(index=False):
            lines.append(
                f"- {r.date} {r.cell_id}: "
                f"{r.n_suppression}/{r.n_negative_voltages} suppressive, "
                f"median r={r.median_r_plateau:.3f}."
            )

    lines += [
        "",
        "Interpretation rule:",
        "Memantine may be used as an experimental pharmacological comparator only.",
        "It must not be represented as B-route deletion in the kinetic model.",
        "",
        "## PPF",
        "",
    ]

    if len(ppf_paired):
        for r in ppf_paired.itertuples(index=False):
            lines.append(
                f"- {r.analysis} {r.date} {r.cell_id}: "
                f"PPR {r.control_ppr:.3f} -> {r.drug_ppr:.3f}, "
                f"delta={r.delta_ppr:+.3f}; "
                f"sweeps {r.control_n_sweeps} vs {r.drug_n_sweeps}."
            )
    else:
        lines.append("No valid paired PPF cell-level results were extracted.")

    lines += [
        "",
        "PPF interpretation rule:",
        "These are descriptive paired cell-level data only. They cannot establish",
        "absence of a presynaptic contribution.",
        "",
        "## Exclusions",
        "",
        '- "Мемантин 9 недель" is excluded from the acute memantine comparison.',
        "- PF / PF_IV is not PPF and is excluded from the paired-pulse analysis.",
        "- Ro25 control files are identified by absence of +Ro25 inside the dated/cell branch;",
        "  the parent folder name Ro25 is not itself treated as drug exposure.",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Step 11 v1.2 manuscript-safety overrides
# ---------------------------------------------------------------------------
PPF_MIN_SNR = 3.0
MEM_MIN_VALID_SWEEP_FRACTION = 0.50
CONTROL_MIN_ABS_PLATEAU_NA = 0.005
CONTROL_MIN_BASELINE_SNR = 3.0


def plateau_sweep_is_endpoint_valid(row) -> bool:
    vals = [
        row.get("plateau_level_nA", np.nan),
        row.get("artifact_count", np.nan),
        row.get("pulse_interval_median_ms", np.nan),
        row.get("negative_fraction", np.nan),
        row.get("interval_cv", np.nan),
        row.get("slope_nA_per_interval", np.nan),
    ]
    if not all(np.isfinite(v) for v in vals):
        return False
    if float(row["plateau_level_nA"]) >= 0:
        return False
    if int(row["artifact_count"]) < 23:
        return False
    if abs(float(row["pulse_interval_median_ms"]) - TRAIN_INTERVAL_MS) > 0.35:
        return False
    if float(row["negative_fraction"]) < 0.70:
        return False
    if float(row["interval_cv"]) > 0.30:
        return False
    if abs(float(row["slope_nA_per_interval"])) > 0.003:
        return False
    return True


def _condition_invalid_reason(endpoint_valid, n_valid, n_total, valid_fraction, plateau_valid):
    if n_total == 0:
        return "no_sweeps"
    if n_valid == 0:
        return "no_endpoint_valid_sweeps"
    if valid_fraction < MEM_MIN_VALID_SWEEP_FRACTION:
        return "endpoint_valid_sweep_fraction_lt_0p5"
    if not np.isfinite(plateau_valid) or plateau_valid >= 0:
        return "valid_sweep_median_not_negative"
    return "" if endpoint_valid else "endpoint_invalid"


def run_memantine_plateau(manifest: pd.DataFrame, out: Path):
    paired = manifest[manifest.pair_status == "paired"].copy()
    sweep_rows = []

    for r in paired.itertuples(index=False):
        sweep_rows += analyze_plateau_file(
            Path(r.control_path), r.date, r.cell_id, r.voltage_mV, "control"
        )
        sweep_rows += analyze_plateau_file(
            Path(r.memantine_path), r.date, r.cell_id, r.voltage_mV, "memantine"
        )

    sweeps = pd.DataFrame(sweep_rows)
    if len(sweeps):
        sweeps["endpoint_valid_sweep"] = sweeps.apply(
            lambda r: plateau_sweep_is_endpoint_valid(r), axis=1
        )
    else:
        sweeps["endpoint_valid_sweep"] = pd.Series(dtype=bool)
    sweeps.to_csv(
        out / "04_memantine_plateau_sweep_metrics_v1_2.csv.gz",
        index=False,
        compression="gzip",
    )

    agg_rows = []
    if len(sweeps):
        for key, g in sweeps.groupby(["date", "cell_id", "voltage_mV", "condition"]):
            date, cell, voltage, condition = key
            finite_all = g[np.isfinite(pd.to_numeric(g.plateau_level_nA, errors="coerce"))]
            gv = g[g.endpoint_valid_sweep].copy()
            n_total = int(len(g))
            n_valid = int(len(gv))
            valid_fraction = n_valid / n_total if n_total else 0.0
            plateau_all = float(np.median(finite_all.plateau_level_nA)) if len(finite_all) else np.nan
            plateau_valid = float(np.median(gv.plateau_level_nA)) if len(gv) else np.nan
            base_sd = float(np.median(gv.baseline_sd_nA)) if len(gv) else np.nan
            endpoint_valid = bool(
                n_valid > 0
                and valid_fraction >= MEM_MIN_VALID_SWEEP_FRACTION
                and np.isfinite(plateau_valid)
                and plateau_valid < 0
            )
            agg_rows.append({
                "date": date,
                "cell_id": cell,
                "voltage_mV": int(voltage),
                "condition": condition,
                "n_sweeps_total": n_total,
                "n_sweeps_endpoint_valid": n_valid,
                "endpoint_valid_sweep_fraction": valid_fraction,
                "plateau_all_sweeps_median_nA": plateau_all,
                "plateau_valid_sweeps_median_nA": plateau_valid,
                "baseline_sd_valid_sweeps_median_nA": base_sd,
                "endpoint_valid_condition": endpoint_valid,
                "condition_invalid_reason": _condition_invalid_reason(
                    endpoint_valid, n_valid, n_total, valid_fraction, plateau_valid
                ),
                "n_qc_flagged_sweeps": int((g.qc_flags.fillna("") != "").sum()),
            })
    agg = pd.DataFrame(agg_rows)
    agg.to_csv(out / "05_memantine_plateau_cell_condition_v1_2.csv", index=False)

    ratios = []
    if len(agg):
        for key, g in agg.groupby(["date", "cell_id", "voltage_mV"]):
            date, cell, voltage = key
            c = g[g.condition == "control"]
            m = g[g.condition == "memantine"]
            if len(c) != 1 or len(m) != 1:
                continue
            c0 = c.iloc[0]
            m0 = m.iloc[0]
            c_all = float(c0.plateau_all_sweeps_median_nA)
            m_all = float(m0.plateau_all_sweeps_median_nA)
            raw_ratio = abs(m_all) / abs(c_all) if np.isfinite(c_all) and c_all != 0 and np.isfinite(m_all) else np.nan
            c_valid = bool(c0.endpoint_valid_condition)
            m_valid = bool(m0.endpoint_valid_condition)
            c_plateau = float(c0.plateau_valid_sweeps_median_nA)
            m_plateau = float(m0.plateau_valid_sweeps_median_nA)
            c_noise = float(c0.baseline_sd_valid_sweeps_median_nA)
            c_signal_snr = abs(c_plateau) / c_noise if np.isfinite(c_plateau) and np.isfinite(c_noise) and c_noise > 0 else np.nan
            c_signal_valid = bool(
                c_valid
                and abs(c_plateau) >= CONTROL_MIN_ABS_PLATEAU_NA
                and np.isfinite(c_signal_snr)
                and c_signal_snr >= CONTROL_MIN_BASELINE_SNR
            )
            quantitative_valid = bool(c_valid and m_valid and c_signal_valid)
            r_valid = abs(m_plateau) / abs(c_plateau) if quantitative_valid and c_plateau != 0 else np.nan
            reasons = []
            if not c_valid:
                reasons.append("control_endpoint_invalid")
            if not m_valid:
                reasons.append("memantine_endpoint_invalid")
            if c_valid and not c_signal_valid:
                reasons.append("control_signal_below_frozen_ratio_gate")
            ratios.append({
                "date": date,
                "cell_id": cell,
                "voltage_mV": int(voltage),
                "control_plateau_all_nA": c_all,
                "memantine_plateau_all_nA": m_all,
                "raw_abs_ratio_all_sweeps": raw_ratio,
                "control_plateau_valid_nA": c_plateau,
                "memantine_plateau_valid_nA": m_plateau,
                "control_endpoint_valid": c_valid,
                "memantine_endpoint_valid": m_valid,
                "control_signal_snr": c_signal_snr,
                "control_signal_valid": c_signal_valid,
                "quantitative_valid": quantitative_valid,
                "r_plateau": r_valid,
                "direction": (
                    "suppression" if quantitative_valid and r_valid < 1
                    else "potentiation" if quantitative_valid and r_valid > 1
                    else "neutral" if quantitative_valid and r_valid == 1
                    else "excluded"
                ),
                "exclusion_reason": ";".join(reasons),
                "control_relation": "within-cell acute control",
            })
    ratios = pd.DataFrame(ratios)
    ratios.to_csv(out / "06_memantine_paired_plateau_ratios_all_v1_2.csv", index=False)

    minus40_all = ratios[ratios.voltage_mV == -40].copy() if len(ratios) else ratios
    minus40_all.to_csv(out / "07_memantine_minus40_all_with_validity.csv", index=False)
    minus40_valid = minus40_all[minus40_all.quantitative_valid].copy() if len(minus40_all) else minus40_all
    minus40_valid.to_csv(out / "08_memantine_minus40_quantitative_valid.csv", index=False)

    robust_rows = []
    if len(ratios):
        valid = ratios[ratios.quantitative_valid & ratios.voltage_mV.isin(NEGATIVE_VOLTAGES)].copy()
        for (date, cell), g in valid.groupby(["date", "cell_id"]):
            robust_rows.append({
                "date": date,
                "cell_id": cell,
                "n_valid_negative_voltages": int(len(g)),
                "n_suppression": int((g.r_plateau < 1).sum()),
                "n_potentiation": int((g.r_plateau > 1).sum()),
                "median_r_plateau": float(np.median(g.r_plateau)) if len(g) else np.nan,
                "all_valid_negative_voltages_suppressive": bool(len(g) > 0 and np.all(g.r_plateau < 1)),
            })
    robust = pd.DataFrame(robust_rows)
    robust.to_csv(out / "09_memantine_negative_voltage_robustness_quantitative_valid.csv", index=False)

    return sweeps, agg, ratios, minus40_valid, robust


def local_baseline_stats(t_ms: np.ndarray, y: np.ndarray, stim: float):
    w = (
        (t_ms >= stim - PPF_LOCAL_BASELINE_START_MS)
        & (t_ms <= stim - PPF_LOCAL_BASELINE_END_MS)
    )
    if w.sum() < 3:
        w = (t_ms >= max(0, stim - 15.0)) & (t_ms <= stim - 1.0)
    if w.sum() < 3:
        return np.nan, np.nan
    vals = y[w]
    return float(np.median(vals)), robust_sd(vals)


def inward_response_measure(
    t_ms: np.ndarray,
    y: np.ndarray,
    stim: float,
    next_stim: Optional[float],
):
    start = stim + PPF_ARTIFACT_GUARD_MS
    stop = min(t_ms[-1], stim + PPF_RESPONSE_MAX_MS)
    if next_stim is not None:
        stop = min(stop, next_stim - PPF_ARTIFACT_GUARD_MS)
    w = (t_ms >= start) & (t_ms <= stop)
    if w.sum() < 5:
        return np.nan, np.nan, np.nan
    base, noise = local_baseline_stats(t_ms, y, stim)
    if not np.isfinite(base):
        return np.nan, noise, np.nan
    seg = y[w] - base
    n = max(3, int(math.ceil(0.05 * len(seg))))
    low = np.partition(seg, n - 1)[:n]
    amp = max(0.0, -float(np.mean(low)))
    snr = amp / noise if np.isfinite(noise) and noise > 0 else np.nan
    return amp, noise, snr


def ppf_metric(t_ms: np.ndarray, y_nA: np.ndarray) -> dict:
    stims = detect_ppf_stims(t_ms, y_nA)
    flags = []
    if len(stims) != 2:
        return {
            "stim1_ms": np.nan,
            "stim2_ms": np.nan,
            "isi_ms": np.nan,
            "response1_nA": np.nan,
            "response2_nA": np.nan,
            "response1_noise_nA": np.nan,
            "response2_noise_nA": np.nan,
            "response1_snr": np.nan,
            "response2_snr": np.nan,
            "min_response_snr": np.nan,
            "ppr_raw": np.nan,
            "ppr": np.nan,
            "ppr_valid_sweep": False,
            "qc_flags": "cannot_extract_two_stims",
        }
    s1, s2 = map(float, stims)
    a1, n1, snr1 = inward_response_measure(t_ms, y_nA, s1, s2)
    a2, n2, snr2 = inward_response_measure(t_ms, y_nA, s2, None)
    raw = a2 / a1 if np.isfinite(a1) and a1 > 0 and np.isfinite(a2) else np.nan
    if not np.isfinite(snr1) or snr1 < PPF_MIN_SNR:
        flags.append("response1_snr_lt3")
    if not np.isfinite(snr2) or snr2 < PPF_MIN_SNR:
        flags.append("response2_snr_lt3")
    if np.isfinite(raw) and (raw < 0.1 or raw > 10):
        flags.append("ppr_extreme")
    valid = bool(
        np.isfinite(raw)
        and np.isfinite(snr1)
        and np.isfinite(snr2)
        and snr1 >= PPF_MIN_SNR
        and snr2 >= PPF_MIN_SNR
        and 0.1 <= raw <= 10
    )
    return {
        "stim1_ms": s1,
        "stim2_ms": s2,
        "isi_ms": s2 - s1,
        "response1_nA": a1,
        "response2_nA": a2,
        "response1_noise_nA": n1,
        "response2_noise_nA": n2,
        "response1_snr": snr1,
        "response2_snr": snr2,
        "min_response_snr": min(snr1, snr2) if np.isfinite(snr1) and np.isfinite(snr2) else np.nan,
        "ppr_raw": raw,
        "ppr": raw if valid else np.nan,
        "ppr_valid_sweep": valid,
        "qc_flags": ";".join(flags),
    }


def run_ppf(ro_manifest: pd.DataFrame, mem_manifest: pd.DataFrame, out: Path):
    rows = []
    for r in ro_manifest[ro_manifest.pair_status == "paired"].itertuples(index=False):
        rows += analyze_ppf_file(Path(r.control_path), r.date, r.cell_id, "control", "ro25_nbqx")
        rows += analyze_ppf_file(Path(r.ro25_path), r.date, r.cell_id, "ro25", "ro25_nbqx")
    for r in mem_manifest[mem_manifest.pair_status == "paired"].itertuples(index=False):
        rows += analyze_ppf_file(Path(r.control_path), r.date, r.cell_id, "control", "memantine_acute")
        rows += analyze_ppf_file(Path(r.memantine_path), r.date, r.cell_id, "memantine", "memantine_acute")

    sweeps = pd.DataFrame(rows)
    sweeps.to_csv(out / "11_ppf_sweep_metrics_with_snr.csv.gz", index=False, compression="gzip")

    agg_rows = []
    if len(sweeps):
        for key, g in sweeps.groupby(["analysis", "date", "cell_id", "condition"]):
            analysis, date, cell, condition = key
            valid = g[g.ppr_valid_sweep == True].copy()
            n_total = int(len(g))
            n_valid = int(len(valid))
            valid_fraction = n_valid / n_total if n_total else 0.0
            cond_valid = bool(n_valid > 0 and valid_fraction >= 0.50)
            agg_rows.append({
                "analysis": analysis,
                "date": date,
                "cell_id": cell,
                "condition": condition,
                "n_sweeps_total": n_total,
                "n_sweeps_ppr_valid": n_valid,
                "ppr_valid_sweep_fraction": valid_fraction,
                "condition_ppr_signal_valid": cond_valid,
                "median_ppr_valid": float(np.median(valid.ppr)) if len(valid) else np.nan,
                "q25_ppr_valid": float(np.quantile(valid.ppr, 0.25)) if len(valid) else np.nan,
                "q75_ppr_valid": float(np.quantile(valid.ppr, 0.75)) if len(valid) else np.nan,
                "median_response1_nA": float(np.median(g.response1_nA.dropna())) if g.response1_nA.notna().any() else np.nan,
                "median_response2_nA": float(np.median(g.response2_nA.dropna())) if g.response2_nA.notna().any() else np.nan,
                "median_response1_snr": float(np.median(g.response1_snr.dropna())) if g.response1_snr.notna().any() else np.nan,
                "median_response2_snr": float(np.median(g.response2_snr.dropna())) if g.response2_snr.notna().any() else np.nan,
                "median_min_response_snr": float(np.median(g.min_response_snr.dropna())) if g.min_response_snr.notna().any() else np.nan,
                "median_isi_ms": float(np.median(g.isi_ms.dropna())) if g.isi_ms.notna().any() else np.nan,
                "single_sweep_condition": bool(n_total == 1),
            })
    agg = pd.DataFrame(agg_rows)
    agg.to_csv(out / "12_ppf_cell_condition_with_snr.csv", index=False)

    paired_rows = []
    if len(agg):
        for key, g in agg.groupby(["analysis", "date", "cell_id"]):
            analysis, date, cell = key
            c = g[g.condition == "control"]
            if analysis == "ro25_nbqx":
                d = g[g.condition == "ro25"]
                drug = "ro25"
            else:
                d = g[g.condition == "memantine"]
                drug = "memantine"
            if len(c) != 1 or len(d) != 1:
                continue
            c0, d0 = c.iloc[0], d.iloc[0]
            signal_valid = bool(c0.condition_ppr_signal_valid and d0.condition_ppr_signal_valid)
            cppr = float(c0.median_ppr_valid)
            dppr = float(d0.median_ppr_valid)
            control_mean_amp = np.nanmean([c0.median_response1_nA, c0.median_response2_nA])
            drug_mean_amp = np.nanmean([d0.median_response1_nA, d0.median_response2_nA])
            retention = drug_mean_amp / control_mean_amp if np.isfinite(control_mean_amp) and control_mean_amp > 0 else np.nan
            notes = []
            if not signal_valid:
                notes.append("PPR_not_interpretable_due_to_SNR_gate")
            if int(d0.n_sweeps_total) == 1:
                notes.append("single_drug_sweep")
            paired_rows.append({
                "analysis": analysis,
                "date": date,
                "cell_id": cell,
                "drug": drug,
                "control_n_sweeps_total": int(c0.n_sweeps_total),
                "drug_n_sweeps_total": int(d0.n_sweeps_total),
                "control_n_sweeps_ppr_valid": int(c0.n_sweeps_ppr_valid),
                "drug_n_sweeps_ppr_valid": int(d0.n_sweeps_ppr_valid),
                "control_ppr": cppr if signal_valid else np.nan,
                "drug_ppr": dppr if signal_valid else np.nan,
                "delta_ppr": dppr - cppr if signal_valid else np.nan,
                "control_median_min_snr": float(c0.median_min_response_snr),
                "drug_median_min_snr": float(d0.median_min_response_snr),
                "control_mean_response_nA": control_mean_amp,
                "drug_mean_response_nA": drug_mean_amp,
                "drug_response_amplitude_retention": retention,
                "ppr_signal_interpretable": signal_valid,
                "sweep_imbalance_ratio": float(max(c0.n_sweeps_total, d0.n_sweeps_total) / max(1, min(c0.n_sweeps_total, d0.n_sweeps_total))),
                "interpretation_notes": ";".join(notes),
            })
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(out / "13_ppf_paired_cell_results_with_snr.csv", index=False)
    return sweeps, agg, paired


def ppf_audit_pdf(sweeps: pd.DataFrame, out: Path):
    if len(sweeps) == 0:
        return
    pdf_path = out / "14_ppf_qc_audit_v1_2.pdf"
    with PdfPages(pdf_path) as pdf:
        for path, g in sweeps.groupby("path"):
            try:
                raw = read_abf_sweeps(Path(path))
            except Exception:
                continue
            for sweep, t_ms, y_nA, unit in raw[:8]:
                row = g[g.sweep == sweep]
                if len(row) == 0:
                    continue
                r = row.iloc[0]
                fig, ax = plt.subplots(figsize=(8.5, 4.5))
                ax.plot(t_ms, y_nA, linewidth=1)
                if np.isfinite(r.stim1_ms):
                    ax.axvline(r.stim1_ms, linestyle="--", linewidth=1)
                if np.isfinite(r.stim2_ms):
                    ax.axvline(r.stim2_ms, linestyle="--", linewidth=1)
                title = (
                    f"{r.analysis} | {r.date} {r.cell_id} | {r.condition} | sweep {sweep}\n"
                    f"PPRraw={r.ppr_raw:.3f} | SNR1={r.response1_snr:.2f} | "
                    f"SNR2={r.response2_snr:.2f} | valid={bool(r.ppr_valid_sweep)}"
                    if np.isfinite(r.ppr_raw)
                    else f"{r.analysis} | {r.date} {r.cell_id} | {r.condition} | sweep {sweep}\nPPR=NA"
                )
                ax.set_title(title)
                ax.set_xlabel("Time (ms)")
                ax.set_ylabel("Current (nA)")
                fig.tight_layout()
                pdf.savefig(fig)
                plt.close(fig)


def decision_text(mem_manifest, mem40, mem_robust, ppf_paired) -> str:
    lines = [
        "# Step 11 v1.2 manuscript decision support",
        "",
        "## Acute memantine SlowEPSC after endpoint-validity gate",
        "",
        f"Quantitatively valid -40 mV cell series: {len(mem40)}.",
    ]
    if len(mem40):
        lines += [
            f"Suppression (r<1): {int((mem40.r_plateau < 1).sum())}.",
            f"Potentiation (r>1): {int((mem40.r_plateau > 1).sum())}.",
            f"Median valid r_plateau: {float(np.median(mem40.r_plateau)):.4f}.",
        ]
    else:
        lines.append("No -40 mV pair passed the quantitative endpoint gate.")
    lines += [
        "",
        "Only pairs with stable negative plateaus in both conditions and a valid control signal",
        "enter the quantitative memantine comparison. Positive or unstable apparent plateaus are excluded.",
        "",
        "## PPF after SNR gate",
        "",
    ]
    if len(ppf_paired):
        for r in ppf_paired.itertuples(index=False):
            if bool(r.ppr_signal_interpretable):
                lines.append(
                    f"- {r.analysis} {r.date} {r.cell_id}: PPR {r.control_ppr:.3f} -> {r.drug_ppr:.3f}, "
                    f"delta={r.delta_ppr:+.3f}; drug/control mean-response retention={r.drug_response_amplitude_retention:.3f}; "
                    f"notes={r.interpretation_notes or 'none'}."
                )
            else:
                lines.append(
                    f"- {r.analysis} {r.date} {r.cell_id}: PPR excluded by SNR gate; "
                    f"drug/control mean-response retention={r.drug_response_amplitude_retention:.3f}; "
                    f"notes={r.interpretation_notes}."
                )
    else:
        lines.append("No paired PPF results were produced.")
    lines += [
        "",
        "PPF remains descriptive supporting evidence only and cannot exclude a presynaptic contribution.",
        "Memantine remains an experimental comparator and is not modeled as B-route deletion.",
        "",
    ]
    return "\n".join(lines)


def self_test():
    # Plateau synthetic test.
    dt = 0.05
    t = np.arange(0, 170 + dt, dt)
    y = np.zeros_like(t)
    pulses = 10 + np.arange(25) * 5.1
    for p in pulses:
        y += 1.0 * np.exp(-0.5 * ((t-p)/0.07)**2)
    for a, b in zip(pulses[:-1], pulses[1:]):
        w = (t >= a+0.5) & (t <= b-0.5)
        y[w] += -0.12
    m = plateau_metric(t, y)
    assert m["artifact_count"] >= 23, m
    assert abs(m["plateau_level_nA"] + 0.12) < 0.02, m

    # Voltage parsing tests matching verified archive names.
    tests = {
        "/x/Cell1 +NBQX +Mem slowEPSC -40Group1Series1.abf": -40,
        "/x/SlowEPSC2+mem-70Group1Series1.abf": -70,
        "/x/SlowEPSC2-40+memGroup1Series1.abf": -40,
        "/x/Cell1/Slow+mem/+20Group1Series1.abf": 20,
        "/x/Cell1/Slow/-0Group1Series1.abf": 0,
    }
    for s, expected in tests.items():
        got = parse_voltage(Path(s))
        assert got == expected, (s, got, expected)

    # Classifier tests.
    assert is_ppf(Path("/x/PPF+NBQXGroup1Series1.abf"))
    assert not is_ppf(Path("/x/PF_IV+NBQX/-40Group1Series1.abf"))
    assert has_mem_marker(Path("/x/Slow+mem/-40Group1Series1.abf"))

    print("SELF-TEST PASS")
    print(json.dumps(m, indent=2, default=float))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--raw-root",
        type=Path,
        default=DEFAULT_RAW_ROOT,
        help="IV_NMDA root; default ~/nmda/IV_NMDA",
    )
    ap.add_argument(
        "--output",
        type=Path,
        default=None,
    )
    ap.add_argument("--self-test", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        self_test()
        return

    here = Path(__file__).resolve().parent
    raw_root = args.raw_root.expanduser().resolve()
    if not raw_root.is_dir():
        raise FileNotFoundError(f"IV_NMDA root not found: {raw_root}")

    out = (args.output or (here / "results_v1_2")).resolve()
    out.mkdir(parents=True, exist_ok=True)

    inv = build_inventory(raw_root)
    inv.to_csv(out / "01_abf_inventory.csv", index=False)

    mem_manifest = acute_mem_manifest(inv)
    mem_manifest.to_csv(out / "02_acute_memantine_pair_manifest.csv", index=False)

    ro_ppf_manifest = ro25_ppf_manifest(inv)
    ro_ppf_manifest.to_csv(out / "03_ro25_ppf_pair_manifest.csv", index=False)

    mem_ppf = mem_ppf_manifest(inv)
    mem_ppf.to_csv(out / "03b_memantine_ppf_pair_manifest.csv", index=False)

    # Fail early if the verified core pairs are not present exactly.
    expected_mem40_cells = {
        ("2021-12-02", "cell1"),
        ("2021-12-02", "cell2"),
        ("2021-12-03", "cell1"),
        ("2022-03-15", "cell2"),
        ("2022-06-22", "cell2"),
        ("2022-06-29", "cell_unlabeled"),
        ("2022-09-26", "cell1"),
        ("2022-09-26", "cell2"),
    }
    observed_mem40 = {
        (r.date, r.cell_id)
        for r in mem_manifest[
            (mem_manifest.voltage_mV == -40)
            & (mem_manifest.pair_status == "paired")
        ].itertuples(index=False)
    }
    missing = sorted(expected_mem40_cells - observed_mem40)
    if missing:
        print("WARNING: expected acute memantine -40 pairs missing:", missing)

    expected_ro = {("2022-10-17", "cell1"), ("2022-10-17", "cell2")}
    observed_ro = {
        (r.date, r.cell_id)
        for r in ro_ppf_manifest[
            ro_ppf_manifest.pair_status == "paired"
        ].itertuples(index=False)
    }
    missing_ro = sorted(expected_ro - observed_ro)
    if missing_ro:
        print("WARNING: expected Ro25 PPF pairs missing:", missing_ro)

    mem_sweeps, mem_agg, mem_ratios, mem40, mem_robust = run_memantine_plateau(
        mem_manifest, out
    )
    ppf_sweeps, ppf_agg, ppf_paired = run_ppf(
        ro_ppf_manifest, mem_ppf, out
    )
    ppf_audit_pdf(ppf_sweeps, out)
    make_figures(mem40, ppf_paired, out)

    decision = decision_text(
        mem_manifest, mem40, mem_robust, ppf_paired
    )
    (out / "15_MANUSCRIPT_DECISION_v1_2.md").write_text(
        decision, encoding="utf-8"
    )

    summary = {
        "pipeline": "NMDAR_Braess_step11_experimental_controls_v1_2",
        "version": VERSION,
        "raw_root": str(raw_root),
        "acute_memantine_chronic_folder_excluded": True,
        "PF_treated_as_PPF": False,
        "acute_memantine_minus40_pairs": int(len(mem40)),
        "ro25_ppf_paired_cells": int(
            (ppf_paired.analysis == "ro25_nbqx").sum()
        ) if len(ppf_paired) else 0,
        "memantine_ppf_paired_cells": int(
            (ppf_paired.analysis == "memantine_acute").sum()
        ) if len(ppf_paired) else 0,
        "p_values_added": False,
        "sweeps_used_as_independent_biological_replicates": False,
        "ppf_used_to_exclude_presynaptic_contribution": False,
        "memantine_modeled_as_route_removal": False,
        "endpoint_validity_gate_added": True,
        "ppf_snr_gate_added": True,
        "ppf_min_snr": PPF_MIN_SNR,
    }
    (out / "run_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    print(decision)
    print()
    print(f"Results: {out}")


if __name__ == "__main__":
    main()
