#!/usr/bin/env python3
"""Audit frozen Step11 v1.2 result tables and build manuscript supplements.

No raw extraction, refitting, selection-threshold changes or inference is done.
Run: python build_step11_publication.py --input RESULTS --output BUILD
"""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

NEGATIVE = [-80, -70, -60, -40, -20]
KEY = ['date', 'cell_id', 'voltage_mV']
FILES = {
 'pairs':'06_memantine_paired_plateau_ratios_all_v1_2.csv',
 'cond':'05_memantine_plateau_cell_condition_v1_2.csv',
 'm40':'07_memantine_minus40_all_with_validity.csv',
 'v40':'08_memantine_minus40_quantitative_valid.csv',
 'robust':'09_memantine_negative_voltage_robustness_quantitative_valid.csv',
 'msweeps':'04_memantine_plateau_sweep_metrics_v1_2.csv.gz',
 'psweeps':'11_ppf_sweep_metrics_with_snr.csv.gz',
 'pcond':'12_ppf_cell_condition_with_snr.csv',
 'ppairs':'13_ppf_paired_cell_results_with_snr.csv',
}

def sha(p):
 return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def close(a,b):
 if not np.allclose(np.asarray(a,float),np.asarray(b,float),rtol=1e-10,atol=1e-12,equal_nan=True):
  raise AssertionError(f'Numeric mismatch: {a} != {b}')

def label(date,cell):
 return date + ' ' + ('unlabelled' if cell=='cell_unlabeled' else cell.replace('cell','C'))

def tex(x):
 return str(x).replace('_',r'\_').replace('%',r'\%').replace('&',r'\&')

def num(x,nd=3):
 return '--' if pd.isna(x) else f'{x:.{nd}f}'

def audit(d):
 p,c,ms,ps,pc,pp=[d[k] for k in ['pairs','cond','msweeps','psweeps','pcond','ppairs']]
 assert not p.duplicated(KEY).any()
 assert not c.duplicated(KEY+['condition']).any()
 assert len(p)==66 and len(p[p.voltage_mV==-40])==8
 n=p[p.voltage_mV.isin(NEGATIVE)];v=n[n.quantitative_valid]
 assert len(n)==40 and len(v)==11
 assert len(v[['date','cell_id']].drop_duplicates())==4
 assert (v.r_plateau<1).all() and (v.r_plateau>0).all()
 assert p.quantitative_valid.sum()==15
 for _,r in c.iterrows():
  g=ms[(ms.date==r.date)&(ms.cell_id==r.cell_id)&(ms.voltage_mV==r.voltage_mV)&(ms.condition==r.condition)]
  x=g[g.endpoint_valid_sweep]
  assert len(g)==r.n_sweeps_total and len(x)==r.n_sweeps_endpoint_valid
  assert bool(r.endpoint_valid_condition)==(len(x)>0 and len(x)/len(g)>=.5 and x.plateau_level_nA.median()<0)
  close(x.plateau_level_nA.median() if len(x) else np.nan,r.plateau_valid_sweeps_median_nA)
 for _,r in p.iterrows():
  g=c[(c.date==r.date)&(c.cell_id==r.cell_id)&(c.voltage_mV==r.voltage_mV)]
  a=g[g.condition=='control'].iloc[0];b=g[g.condition=='memantine'].iloc[0]
  cv=a.plateau_valid_sweeps_median_nA; bv=b.plateau_valid_sweeps_median_nA
  noise=a.baseline_sd_valid_sweeps_median_nA
  eligible=bool(a.endpoint_valid_condition and b.endpoint_valid_condition and np.isfinite(noise) and noise>0 and abs(cv)>=.005 and abs(cv)/noise>=3)
  assert bool(r.quantitative_valid)==eligible
  close(r.r_plateau, abs(bv)/abs(cv) if eligible else np.nan)
 assert (ms[ms.endpoint_valid_sweep].artifact_count==25).all()
 for _,r in pc.iterrows():
  g=ps[(ps.analysis==r.analysis)&(ps.date==r.date)&(ps.cell_id==r.cell_id)&(ps.condition==r.condition)]
  x=g[g.ppr_valid_sweep]
  eligible=np.isfinite(g.ppr_raw)&(g.response1_snr>=3)&(g.response2_snr>=3)&g.ppr_raw.between(.1,10)
  assert (eligible==g.ppr_valid_sweep).all()
  assert len(x)==r.n_sweeps_ppr_valid and len(g)==r.n_sweeps_total
  assert bool(r.condition_ppr_signal_valid)==(len(x)>0 and len(x)/len(g)>=.5)
  close(x.ppr.median(),r.median_ppr_valid)
  close(g.response1_nA.median(),r.median_response1_nA)
  close(g.response2_nA.median(),r.median_response2_nA)
 for _,r in pp.iterrows():
  g=pc[(pc.analysis==r.analysis)&(pc.date==r.date)&(pc.cell_id==r.cell_id)]
  a=g[g.condition=='control'].iloc[0];b=g[g.condition==r.drug].iloc[0]
  ok=bool(a.condition_ppr_signal_valid and b.condition_ppr_signal_valid)
  assert bool(r.ppr_signal_interpretable)==ok
  close(r.drug_response_amplitude_retention,(b.median_response1_nA+b.median_response2_nA)/(a.median_response1_nA+a.median_response2_nA))
  close(r.delta_ppr,b.median_ppr_valid-a.median_ppr_valid if ok else np.nan)
 v40=v[v.voltage_mV==-40].sort_values(KEY)
 close(v40.r_plateau,d['v40'].sort_values(KEY).r_plateau)
 assert list(d['robust'].n_valid_negative_voltages)==[2,1,5,3]
 return {
  'status':'PASS', 'raw_recomputed':False, 'new_thresholds':False,
  'total_memantine_voltage_pairs':len(p), 'all_voltage_eligible_pairs':int(p.quantitative_valid.sum()),
  'negative_voltage_candidate_pairs':len(n), 'negative_voltage_eligible_pairs':len(v),
  'negative_voltage_eligible_cell_series':4, 'negative_voltage_suppression_count':int((v.r_plateau<1).sum()),
  'minus40_candidates':8, 'minus40_eligible':2, 'minus40_ratios':v40.r_plateau.tolist(),
  'minus40_ratio_median':float(v40.r_plateau.median()),
  'negative_eligible_by_cell':d['robust'][['date','cell_id','n_valid_negative_voltages']].to_dict('records'),
  'ppf_sweeps':len(ps), 'ppf_pairs':len(pp), 'ppf_signal_interpretable_pairs':int(pp.ppr_signal_interpretable.sum()),
  'all_eligible_memantine_sweeps_have_25_artifacts':True,
  'correction_to_previous_chat':'15 eligible rows refer to all voltages, including 0, +20 and +60 mV; only 11 are at the five planned negative voltages.',
  'limitations':['Ancillary QC gate specified after v1.1 inspection, not preregistered.',
   'Eligibility is conditioned on a measurable negative plateau in both conditions; near-complete block may fail it.',
   'No between-drug statistical comparison; distinct archives and control schemes.',
   'Unlabelled 29 June series identity is inferred from archive structure.',
   'Ro25 PPF has NBQX labels; acute memantine PPF does not establish NBQX status.',
   'Local-baseline PPR is not a deconvolved release-probability measurement.']
 }

def tables(d,out):
 p,c=d['pairs'],d['cond'];n=p[p.voltage_mV.isin(NEGATIVE)].sort_values(KEY)
 def cn(row,condition):
  return c[(c.date==row.date)&(c.cell_id==row.cell_id)&(c.voltage_mV==row.voltage_mV)&(c.condition==condition)].iloc[0]
 lines=[r'\begingroup\small\setlength{\tabcolsep}{4pt}\renewcommand{\arraystretch}{1.10}',
 r'\begin{longtable}{@{}llrrrrrl@{}}',
 r'\caption{All archive-matched acute memantine pairs at the five planned negative voltages.}\label{tab:S10}\\',
 r'\toprule Cell series & $V$ (mV) & $n_C$ & $n_M$ & $I_C$ (pA) & $I_M$ (pA) & $r$ & Status \\ \midrule\endfirsthead',
 r'\toprule Cell series & $V$ (mV) & $n_C$ & $n_M$ & $I_C$ (pA) & $I_M$ (pA) & $r$ & Status \\ \midrule\endhead']
 for _,r in n.iterrows():
  a,b=cn(r,'control'),cn(r,'memantine')
  stat='eligible' if r.quantitative_valid else ('C+M' if not r.control_endpoint_valid and not r.memantine_endpoint_valid else 'C' if not r.control_endpoint_valid else 'M' if not r.memantine_endpoint_valid else 'C signal')
  lines.append(' & '.join([tex(label(r.date,r.cell_id)),str(r.voltage_mV),f'{a.n_sweeps_endpoint_valid}/{a.n_sweeps_total}',f'{b.n_sweeps_endpoint_valid}/{b.n_sweeps_total}',num(r.control_plateau_all_nA*1000,1),num(r.memantine_plateau_all_nA*1000,1),num(r.r_plateau),stat])+r' \\')
 lines.extend([r'\bottomrule\end{longtable}\endgroup',r'\noindent\footnotesize C and M denote control and memantine. Counts are endpoint-valid/total technical sweeps. Currents in this table are medians over \emph{all} sweeps, including flagged sweeps, so excluded measurements remain visible; $r$ uses only valid-sweep medians after both condition gates pass. C, M, or C+M indicate which endpoint failed. There are 11 eligible pairs among 40 negative-voltage pairs, nested in four cell series, not 11 independent cells. The complete 66-row output (including other voltages) is retained in the source data.\normalsize'])
 (out/'table_S10.tex').write_text('\n'.join(lines)+'\n')
 lines=[r'\begin{table}[H]\centering\small',r'\caption{Detailed endpoint decisions for all eight acute memantine pairs at $-40$ mV.}\label{tab:S11}',r'\begin{tabularx}{\textwidth}{@{}lrrrX@{}}\toprule Cell series & $I_C^{\mathrm{valid}}$ & $I_M^{\mathrm{valid}}$ & $r$ & Eligibility decision \\',r' & (pA) & (pA) & & \\ \midrule']
 for _,r in d['m40'].sort_values(KEY).iterrows():
  a,b=cn(r,'control'),cn(r,'memantine')
  if r.quantitative_valid: reason=f'Eligible: C {a.n_sweeps_endpoint_valid}/{a.n_sweeps_total}, M {b.n_sweeps_endpoint_valid}/{b.n_sweeps_total} sweeps.'
  else:
   parts=[]
   if not r.control_endpoint_valid:parts.append(f'C: {a.n_sweeps_endpoint_valid}/{a.n_sweeps_total} valid sweeps')
   if not r.memantine_endpoint_valid:parts.append(f'M: {b.n_sweeps_endpoint_valid}/{b.n_sweeps_total} valid sweeps')
   reason='Excluded; '+', '.join(parts)+'.'
  lines.append(' & '.join([tex(label(r.date,r.cell_id)),num(r.control_plateau_valid_nA*1000,1),num(r.memantine_plateau_valid_nA*1000,1),num(r.r_plateau),tex(reason)])+r' \\')
 lines.extend([r'\bottomrule\end{tabularx}',r'\begin{minipage}{\textwidth}\footnotesize Valid-sweep medians are shown when available, including conditions that fail the required valid-sweep fraction of one half. A single valid drug sweep out of three on 29 June therefore does not produce an eligible pair. The control on 15 March has an all-sweep median of $-405.8$ pA but a valid-sweep median of $-382.3$ pA; the latter determines its ratio. Dashes indicate quantities not admitted to the quantitative comparison.\end{minipage}\end{table}'])
 (out/'table_S11.tex').write_text('\n'.join(lines)+'\n')
 pc=d['pcond']
 lines=[r'\begin{table}[H]\centering\small',r'\caption{Paired-pulse cell-condition measurements and SNR eligibility.}\label{tab:S12}',r'\begin{tabular}{@{}llrrrrrl@{}}\toprule Cell / background & Condition & $n_v/n$ & $A_1$ & $A_2$ & Min SNR & PPR$^*$ & Gate \\',r' & & & (pA) & (pA) & & & \\ \midrule']
 for _,r in pc.iterrows():
  name=('22 Jun C2 / unrecorded' if r.analysis=='memantine_acute' else '17 Oct '+r.cell_id.replace('cell','C')+' / NBQX')
  lines.append(' & '.join([name,{'control':'Control','memantine':'Memantine','ro25':'Ro25'}[r.condition],f'{r.n_sweeps_ppr_valid}/{r.n_sweeps_total}',num(r.median_response1_nA*1000,1),num(r.median_response2_nA*1000,1),num(r.median_min_response_snr,2),num(r.median_ppr_valid),'pass' if r.condition_ppr_signal_valid else 'fail'])+r' \\')
 lines.extend([r'\bottomrule\end{tabular}',r'\begin{minipage}{\textwidth}\footnotesize $n_v/n$ is the number of PPR-valid/total sweeps. Amplitudes are medians across all sweeps. Min SNR is the median across sweeps of the smaller of the two response SNRs. PPR$^*$ is the median of valid sweep-level ratios, not the ratio of the two displayed amplitude medians. The value for Ro25 C1 is retained for QC only: 15/42 sweeps pass, so the condition gate fails and no paired PPR difference is interpreted. All recorded inter-stimulus intervals were 50.1 ms. NBQX status is not established by the memantine PPF filenames.\end{minipage}\end{table}'])
 (out/'table_S12.tex').write_text('\n'.join(lines)+'\n')
 lines=[r'\begin{table}[H]\centering\small',r'\caption{Paired-pulse comparisons after the cell-condition SNR gate.}\label{tab:S13}',r'\begin{tabularx}{\textwidth}{@{}lrrrrX@{}}\toprule Pair & PPR$_C$ & PPR$_D$ & $\Delta$PPR & Retention & Interpretation limit \\ \midrule']
 for _,r in d['ppairs'].iterrows():
  name=('Memantine, 22 Jun C2' if r.drug=='memantine' else 'Ro25, 17 Oct '+r.cell_id.replace('cell','C'))
  limit=('One cell; marked response suppression.' if r.drug=='memantine' else 'PPR excluded: drug-condition SNR gate fails.' if not r.ppr_signal_interpretable else 'Drug condition has one sweep.')
  lines.append(' & '.join([name,num(r.control_ppr),num(r.drug_ppr),num(r.delta_ppr),f'{r.drug_response_amplitude_retention*100:.2f}'+r'\%',limit])+r' \\')
 lines.extend([r'\bottomrule\end{tabularx}',r'\begin{minipage}{\textwidth}\footnotesize Retention is $(\widetilde A_{1,D}+\widetilde A_{2,D})/(\widetilde A_{1,C}+\widetilde A_{2,C})$, where tildes denote condition-wise medians over all sweeps. Retention is a descriptive amplitude measure, not a presynaptic parameter. PPR eligibility does not establish biological replication or identify the site of drug action.\end{minipage}\end{table}'])
 (out/'table_S13.tex').write_text('\n'.join(lines)+'\n')

def figures(d,out):
 plt.rcParams.update({'font.size':10,'pdf.fonttype':42,'ps.fonttype':42})
 p=d['pairs'];v=p[p.quantitative_valid & p.voltage_mV.isin(NEGATIVE)]
 fig,ax=plt.subplots(figsize=(7.4,4.2))
 for (date,cell),g in v.groupby(['date','cell_id'],sort=True):
  ax.plot(g.voltage_mV,g.r_plateau,marker='o',linestyle='none',markersize=7,label=label(date,cell))
 ax.axhline(1,linestyle='--',linewidth=1)
 ax.set(xticks=NEGATIVE,xlabel='Holding potential (mV)',ylabel='Memantine / control plateau ratio',ylim=(0,1.09))
 ax.legend(loc='lower left',frameon=False,fontsize=9)
 fig.tight_layout()
 for ext in ['pdf','png']:fig.savefig(out/f'FigS4_memantine_negative_voltage.{ext}',dpi=220)
 plt.close(fig)
 ps,pc=d['psweeps'],d['pcond']
 ordered=[('ro25_nbqx','cell1','control'),('ro25_nbqx','cell1','ro25'),('ro25_nbqx','cell2','control'),('ro25_nbqx','cell2','ro25'),('memantine_acute','cell2','control'),('memantine_acute','cell2','memantine')]
 fig,ax=plt.subplots(figsize=(8,4.6));labs=[]
 for i,(analysis,cell,condition) in enumerate(ordered):
  g=ps[(ps.analysis==analysis)&(ps.cell_id==cell)&(ps.condition==condition)].sort_values('sweep')
  r=pc[(pc.analysis==analysis)&(pc.cell_id==cell)&(pc.condition==condition)].iloc[0]
  jit=np.zeros(len(g)) if len(g)==1 else np.linspace(-.14,.14,len(g))
  valid=g.ppr_valid_sweep.to_numpy(bool);vals=g.min_response_snr.to_numpy(float)
  ax.scatter((i+jit)[valid],vals[valid],s=25,marker='o')
  if (~valid).any():ax.scatter((i+jit)[~valid],vals[~valid],s=30,marker='x')
  title=('17 Oct '+cell.replace('cell','C') if analysis=='ro25_nbqx' else '22 Jun C2')
  labs.append(title+'\n'+{'control':'Control','ro25':'Ro25 + NBQX','memantine':'Memantine'}[condition]+f'\n{r.n_sweeps_ppr_valid}/{r.n_sweeps_total} valid')
 ax.axhline(3,linestyle='--',linewidth=1)
 ax.text(5.48,3.25,'SNR = 3',ha='right',fontsize=9)
 ax.set(yscale='log',xticks=range(6),xticklabels=labs,ylabel='Minimum of the two response SNRs',ylim=(1.15,140),xlim=(-.45,5.55))
 ax.tick_params(axis='x',labelsize=8.5)
 fig.tight_layout()
 for ext in ['pdf','png']:fig.savefig(out/f'FigS5_ppf_snr_audit.{ext}',dpi=220)
 plt.close(fig)

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--input',required=True,type=Path);ap.add_argument('--output',required=True,type=Path)
 a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 d={k:pd.read_csv(a.input/f) for k,f in FILES.items()}
 result=audit(d)
 result['inputs']={f:sha(a.input/f) for f in FILES.values()}
 (a.output/'step11_publication_audit.json').write_text(json.dumps(result,indent=2)+'\n')
 tables(d,a.output);figures(d,a.output)
 d['pairs'][d['pairs'].voltage_mV.isin(NEGATIVE)].to_csv(a.output/'memantine_negative_voltage_all.csv',index=False)
 d['pairs'][d['pairs'].quantitative_valid & d['pairs'].voltage_mV.isin(NEGATIVE)].to_csv(a.output/'memantine_negative_voltage_valid.csv',index=False)
 print(json.dumps({k:v for k,v in result.items() if k!='inputs'},indent=2))
if __name__=='__main__':main()
