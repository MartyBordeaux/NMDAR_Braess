#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import zipfile
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import beta, spearmanr

VERSION = "1.0.0"
STRONG_DEFAULT = 1.6359295439505144
WITNESS_DEFAULT = 37318
RATE_COLUMNS = [
    "kon_A_per_ms", "kon_B_per_ms", "koff_A_per_ms", "koff_B_per_ms",
    "kf_plus_per_ms", "ks_plus_per_ms", "kf_minus_per_ms", "ks_minus_per_ms",
    "kd1_plus_per_ms", "kd1_minus_per_ms", "kd2_plus_per_ms", "kd2_minus_per_ms",
]
CONTROL_COLUMNS = [
    "control_peak_PO", "control_plateau_PO_140_250", "control_late_PO_200_500",
    "control_charge_PO_ms", "control_early_PO_140_200",
]
SELECTED_Q = [1, 2, 5, 8, 9, 10, 10.1, 10.5, 11, 12, 15, 20, 25, 30, 40, 50, 75, 100]
TARGETS = {
    "primary_5_of_11": (5, 11),
    "leave_extreme_out_4_of_10": (4, 10),
}


def log(msg: str) -> None:
    print(msg, flush=True)


def read_table(spec: str) -> pd.DataFrame:
    spec = str(spec)
    if "::" in spec:
        zpath, member = spec.split("::", 1)
        with zipfile.ZipFile(zpath) as zf:
            with zf.open(member) as fh:
                return pd.read_csv(fh)
    p = Path(spec)
    if p.suffix == ".parquet":
        return pd.read_parquet(p)
    return pd.read_csv(p, compression="infer")


def read_step18_file(step18_spec: str, filename: str) -> pd.DataFrame | dict:
    p = Path(step18_spec)
    if p.is_dir():
        fp = p / filename
        if not fp.exists():
            raise FileNotFoundError(fp)
        if fp.suffix == ".json":
            return json.loads(fp.read_text())
        return pd.read_csv(fp)
    if p.suffix.lower() == ".zip":
        with zipfile.ZipFile(p) as zf:
            candidates = [n for n in zf.namelist() if n.endswith("/" + filename) or n == filename]
            if not candidates:
                raise FileNotFoundError(f"{filename} not found inside {p}")
            member = candidates[0]
            with zf.open(member) as fh:
                if filename.endswith(".json"):
                    return json.loads(fh.read().decode("utf-8"))
                return pd.read_csv(fh)
    raise ValueError(f"Unsupported Step18 results spec: {step18_spec}")


def candidate_roots(extra: str | None = None) -> list[Path]:
    roots: list[Path] = []
    for x in [extra, os.getcwd(), str(Path(os.getcwd()).parent), "/root/nmda2", "/root/nmda", "/home/vlad/nmda", "/home/vlad/nmda2"]:
        if x and Path(x).exists():
            p = Path(x).resolve()
            if p not in roots:
                roots.append(p)
    return roots


def discover_step18(roots: list[Path]) -> str | None:
    preferred = [
        Path("/root/nmda2/step_18/results_step_18_prior_geometry"),
        Path("/root/nmda2/step_18/results_step_18_prior_geometry.zip"),
        Path("/root/nmda2/results_step_18_prior_geometry.zip"),
    ]
    for p in preferred:
        if p.exists():
            return str(p)
    hits: list[Path] = []
    for root in roots:
        for pat in ["results_step_18_prior_geometry", "results_step_18_prior_geometry.zip"]:
            try:
                for p in root.rglob(pat):
                    if p.exists():
                        hits.append(p)
            except Exception:
                pass
    if not hits:
        return None
    hits.sort(key=lambda p: (0 if p.is_dir() else 1, len(str(p))))
    return str(hits[0])


def table_has_required_columns(spec: str) -> bool:
    try:
        h = read_table(spec).head(3)
        return all(c in h.columns for c in RATE_COLUMNS) and "sample_id" in h.columns and "calibration_score" in h.columns
    except Exception:
        return False


def discover_step10_all_samples(roots: list[Path]) -> str | None:
    exact = [
        "/root/nmda/results_step10.zip::results/10_matched_rerouting/matched_parameter_all_samples.csv",
        "/root/nmda/results/10_matched_rerouting/matched_parameter_all_samples.csv",
        "/root/nmda2/results_step10.zip::results/10_matched_rerouting/matched_parameter_all_samples.csv",
    ]
    for spec in exact:
        outer = spec.split("::", 1)[0]
        if Path(outer).exists() and table_has_required_columns(spec):
            return spec
    candidates: list[str] = []
    for root in roots:
        for pat in ["*step10*.zip", "*step_10*.zip"]:
            try:
                for z in root.rglob(pat):
                    if not z.is_file():
                        continue
                    try:
                        with zipfile.ZipFile(z) as zf:
                            for m in zf.namelist():
                                if m.endswith("matched_parameter_all_samples.csv"):
                                    candidates.append(f"{z}::{m}")
                    except Exception:
                        pass
            except Exception:
                pass
        for pat in ["matched_parameter_all_samples.csv", "*all_samples*.csv"]:
            try:
                for p in root.rglob(pat):
                    if p.is_file():
                        candidates.append(str(p))
            except Exception:
                pass
    for spec in candidates:
        if table_has_required_columns(spec):
            return spec
    return None


def prepare_inputs(step18_spec: str, precal_spec: str, outdir: Path, strong: float, witness_id: int) -> pd.DataFrame:
    log("[1/8] Loading Step18 candidate summary")
    s18 = read_step18_file(step18_spec, "03_candidate_grid_summary.csv")
    assert isinstance(s18, pd.DataFrame)
    required_s18 = {"sample_id", "accepted", "r_max_confirmed_or_screen", "strong_anywhere_confirmed"}
    missing = required_s18.difference(s18.columns)
    if missing:
        raise RuntimeError(f"Step18 summary missing columns: {sorted(missing)}")
    if len(s18) != 50000:
        raise RuntimeError(f"Step18 summary has {len(s18)} rows; expected 50000 broad candidates")

    log("[2/8] Loading historical Step10 all-samples table")
    pre = read_table(precal_spec)
    if "prior" in pre.columns:
        pre = pre[pre["prior"].astype(str).str.lower() == "broad"].copy()
    if len(pre) != 50000:
        raise RuntimeError(f"Step10 broad table has {len(pre)} rows; expected 50000")
    need = set(RATE_COLUMNS + ["sample_id", "calibration_score"])
    miss = need.difference(pre.columns)
    if miss:
        raise RuntimeError(f"Historical table missing required columns: {sorted(miss)}")

    pre["sample_id"] = pd.to_numeric(pre["sample_id"], errors="raise").astype(int)
    s18["sample_id"] = pd.to_numeric(s18["sample_id"], errors="raise").astype(int)
    if pre.sample_id.duplicated().any() or s18.sample_id.duplicated().any():
        raise RuntimeError("Duplicate sample_id in Step10 or Step18")

    keep_cols = ["sample_id", "calibration_score"] + RATE_COLUMNS
    for c in CONTROL_COLUMNS + ["accepted_control_calibration", "control_valid", "pulse_amplitude_au", "glutamate_tau_ms"]:
        if c in pre.columns and c not in keep_cols:
            keep_cols.append(c)
    merged = s18.merge(pre[keep_cols], on="sample_id", how="left", validate="one_to_one")
    if merged["calibration_score"].isna().any():
        raise RuntimeError("Missing calibration_score after Step10/Step18 sample_id merge")
    for c in RATE_COLUMNS:
        merged[c] = pd.to_numeric(merged[c], errors="raise")
        if (merged[c] <= 0).any():
            raise RuntimeError(f"Non-positive rate found in {c}")
    merged["calibration_score"] = pd.to_numeric(merged["calibration_score"], errors="raise")
    merged["accepted"] = merged["accepted"].astype(bool)
    merged["strong"] = merged["strong_anywhere_confirmed"].astype(bool)
    merged["r_max"] = pd.to_numeric(merged["r_max_confirmed_or_screen"], errors="coerce")

    accepted_n = int(merged.accepted.sum())
    strong_n = int(merged.strong.sum())
    if accepted_n != 5000:
        raise RuntimeError(f"Merged accepted count {accepted_n}; expected 5000")
    if witness_id not in set(merged.sample_id):
        raise RuntimeError(f"Witness {witness_id} absent")

    med_acc = float(merged.loc[merged.accepted, "calibration_score"].median())
    med_rej = float(merged.loc[~merged.accepted, "calibration_score"].median())
    lower_better = med_acc < med_rej
    if not lower_better:
        raise RuntimeError("Historical calibration_score appears not to use lower-is-better ordering; Step19 v1.0 expects the frozen Step10 convention")

    max_acc = float(merged.loc[merged.accepted, "calibration_score"].max())
    min_rej = float(merged.loc[~merged.accepted, "calibration_score"].min())
    separable = max_acc < min_rej
    cutoff = (max_acc + min_rej) / 2.0 if separable else max_acc
    merged["score_margin_from_historical_cutoff"] = merged["calibration_score"] - cutoff
    merged = merged.sort_values(["calibration_score", "sample_id"], kind="mergesort").reset_index(drop=True)
    merged["calibration_rank"] = np.arange(1, len(merged) + 1)
    merged["calibration_percentile"] = 100.0 * merged["calibration_rank"] / len(merged)

    top10_ids = set(merged.iloc[:5000].sample_id)
    accepted_ids = set(merged.loc[merged.accepted, "sample_id"])
    top10_mismatch = len(top10_ids.symmetric_difference(accepted_ids))
    historical_flag_mismatch = None
    if "accepted_control_calibration" in merged.columns:
        flag = merged["accepted_control_calibration"].astype(bool)
        historical_flag_mismatch = int(np.sum(flag != merged.accepted))

    audit = {
        "version": VERSION,
        "step18_results": step18_spec,
        "step10_all_samples": precal_spec,
        "n_broad": int(len(merged)),
        "n_accepted": accepted_n,
        "n_strong_anywhere": strong_n,
        "strong_threshold": float(strong),
        "witness_id": int(witness_id),
        "witness_accepted": bool(merged.loc[merged.sample_id == witness_id, "accepted"].iloc[0]),
        "witness_strong": bool(merged.loc[merged.sample_id == witness_id, "strong"].iloc[0]),
        "lower_calibration_score_is_better": True,
        "accepted_score_median": med_acc,
        "rejected_score_median": med_rej,
        "max_accepted_score": max_acc,
        "min_rejected_score": min_rej,
        "accepted_rejected_score_separable": bool(separable),
        "historical_cutoff_midpoint": cutoff,
        "top10_percent_vs_accepted_symmetric_difference_n": int(top10_mismatch),
        "accepted_control_calibration_flag_mismatch_n": historical_flag_mismatch,
        "available_control_observables": [c for c in CONTROL_COLUMNS if c in merged.columns],
    }
    (outdir / "00_input_audit.json").write_text(json.dumps(audit, indent=2))
    compact_cols = [
        "sample_id", "calibration_score", "score_margin_from_historical_cutoff",
        "calibration_rank", "calibration_percentile", "accepted", "strong", "r_max",
        "G_peak_at_max", "tau_G_ms_at_max", "n_strong_nodes_screen",
    ] + RATE_COLUMNS + [c for c in CONTROL_COLUMNS if c in merged.columns]
    compact_cols = [c for c in compact_cols if c in merged.columns]
    merged[compact_cols].to_csv(outdir / "00_merged_frontier_input.csv.gz", index=False, compression="gzip")
    log(f"      Input audit PASS: strong={strong_n}/50000, accepted={accepted_n}/50000, cutoff={cutoff:.9g}")
    return merged


def frontier_row(df: pd.DataFrame, q: float) -> dict:
    n_req = max(1, int(math.ceil(len(df) * q / 100.0)))
    sub = df.iloc[:n_req]
    ns = int(sub.strong.sum())
    nb = int((sub.r_max > 1.0).sum())
    return {
        "calibration_top_percent": float(q),
        "n_included": int(len(sub)),
        "score_cutoff": float(sub.calibration_score.iloc[-1]),
        "strong_n": ns,
        "strong_fraction": float(ns / len(sub)),
        "braess_direction_n": nb,
        "braess_direction_fraction": float(nb / len(sub)),
        "r_max_median": float(np.nanmedian(sub.r_max)),
        "r_max_95pct": float(np.nanquantile(sub.r_max, 0.95)),
        "r_max_max": float(np.nanmax(sub.r_max)),
    }


def calibration_frontier(df: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    log("[3/8] Computing calibration-Braess frontier")
    dense_q = np.concatenate([np.arange(0.2, 10.0, 0.2), np.arange(10.0, 20.1, 0.5), np.arange(21, 101, 1)]).astype(float)
    dense = pd.DataFrame([frontier_row(df, q) for q in dense_q])
    selected = pd.DataFrame([frontier_row(df, q) for q in SELECTED_Q])
    dense.to_csv(outdir / "01_calibration_frontier_dense.csv", index=False)
    selected.to_csv(outdir / "01A_calibration_frontier_selected.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.2, 5.0))
    ax.scatter(df.calibration_percentile, df.r_max, s=4, alpha=0.12, rasterized=True)
    strong = df.strong.to_numpy(bool)
    ax.scatter(df.loc[strong, "calibration_percentile"], df.loc[strong, "r_max"], s=9, alpha=0.45, rasterized=True)
    ax.axvline(10.0, linestyle="--", linewidth=1.1)
    ax.axhline(STRONG_DEFAULT, linestyle="--", linewidth=1.1)
    ax.set_xlabel("Control-calibration rank (% of broad candidates retained)")
    ax.set_ylabel(r"Maximum Base response ratio across forcing grid, $r_{max}$")
    ax.set_xlim(0, 100)
    ymax = min(max(4.5, float(np.nanquantile(df.r_max, 0.998))), 15.0)
    ax.set_ylim(0, ymax)
    fig.tight_layout()
    fig.savefig(outdir / "Fig19A_calibration_Braess_frontier.pdf", dpi=300)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    ax.plot(dense.calibration_top_percent, dense.strong_fraction, linewidth=1.5)
    ax.axvline(10.0, linestyle="--", linewidth=1.1)
    ax.axhline(5/11, linestyle=":", linewidth=1.1)
    ax.axhline(4/10, linestyle="-.", linewidth=1.1)
    ax.set_xlabel("Top fraction retained by control calibration (%)")
    ax.set_ylabel("Fraction of sampled parameter sets with strong response")
    ax.set_xlim(0, 100)
    ax.set_ylim(0, max(0.5, float(dense.strong_fraction.max()) * 1.1))
    fig.tight_layout()
    fig.savefig(outdir / "Fig19B_strong_incidence_vs_calibration.pdf", dpi=300)
    plt.close(fig)
    return dense


def clopper_pearson(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alpha / 2, k + 1, n - k))
    return lo, hi


def reweight_feasibility(df: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    log("[4/8] Evaluating support for 5/11 and leave-extreme-out 4/10 targets")
    rows = []
    for q in SELECTED_Q:
        n = max(1, int(math.ceil(len(df) * q / 100.0)))
        sub = df.iloc[:n]
        ns = int(sub.strong.sum())
        nn = n - ns
        f = ns / n
        for name, (k, nt) in TARGETS.items():
            p = k / nt
            if ns == 0 or nn == 0:
                status = "unsupported"
                ess = 0.0
                ess_frac = 0.0
                kl = math.inf
                max_weight = math.nan
                strong_multiplier = math.inf if ns == 0 else p / f
            else:
                # Maximum-entropy/minimum-KL reweighting within this support:
                # uniform weights inside strong and non-strong classes.
                ws = p / ns
                wn = (1 - p) / nn
                ess = 1.0 / (ns * ws * ws + nn * wn * wn)
                ess_frac = ess / n
                kl = p * math.log(p / f) + (1 - p) * math.log((1 - p) / (1 - f))
                max_weight = max(ws, wn)
                strong_multiplier = p / f
                status = "supported"
            rows.append({
                "target": name, "experimental_strong_k": k, "experimental_n": nt,
                "target_fraction": p, "calibration_top_percent": q, "support_n": n,
                "strong_support_n": ns, "strong_support_fraction": f, "status": status,
                "minimum_KL_binary_reweight": kl, "maximum_possible_ESS": ess,
                "maximum_possible_ESS_fraction": ess_frac, "max_single_parameter_weight": max_weight,
                "strong_class_weight_multiplier_vs_uniform": strong_multiplier,
            })
    res = pd.DataFrame(rows)
    res.to_csv(outdir / "02_reweighting_support_feasibility.csv", index=False)

    target_rows = []
    for name, (k, n) in TARGETS.items():
        lo, hi = clopper_pearson(k, n)
        rr = res[(res.target == name) & (res.status == "supported")].copy()
        q10 = rr.loc[rr.maximum_possible_ESS_fraction >= 0.10, "calibration_top_percent"]
        q25 = rr.loc[rr.maximum_possible_ESS_fraction >= 0.25, "calibration_top_percent"]
        target_rows.append({
            "target": name, "k": k, "n": n, "observed_fraction": k/n,
            "exact_95CI_low": lo, "exact_95CI_high": hi,
            "first_selected_calibration_percent_with_ESS_fraction_ge_0p10": None if q10.empty else float(q10.iloc[0]),
            "first_selected_calibration_percent_with_ESS_fraction_ge_0p25": None if q25.empty else float(q25.iloc[0]),
        })
    pd.DataFrame(target_rows).to_csv(outdir / "02A_experimental_target_sensitivity.csv", index=False)

    fig, ax = plt.subplots(figsize=(7.2, 4.8))
    for name in TARGETS:
        rr = res[(res.target == name) & np.isfinite(res.maximum_possible_ESS_fraction)]
        ax.plot(rr.calibration_top_percent, rr.maximum_possible_ESS_fraction, marker="o", markersize=3, label=name)
    ax.axhline(0.10, linestyle="--", linewidth=1.0)
    ax.axhline(0.25, linestyle=":", linewidth=1.0)
    ax.axvline(10.0, linestyle="--", linewidth=1.0)
    ax.set_xlabel("Top fraction retained by control calibration (%)")
    ax.set_ylabel("Maximum achievable ESS / support size")
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 1.02)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(outdir / "Fig19C_reweighting_support_feasibility.pdf", dpi=300)
    plt.close(fig)
    return res


def rejected_strong_boundary(df: pd.DataFrame, outdir: Path) -> dict:
    log("[5/8] Characterizing rejected strong sets nearest the historical cutoff")
    acc = df.accepted.to_numpy(bool)
    strong = df.strong.to_numpy(bool)
    cutoff = float((df.loc[acc, "calibration_score"].max() + df.loc[~acc, "calibration_score"].min()) / 2.0)
    rejstrong = df[(~df.accepted) & df.strong].copy().sort_values("calibration_score")
    cols = [
        "sample_id", "calibration_score", "score_margin_from_historical_cutoff",
        "calibration_rank", "calibration_percentile", "r_max", "G_peak_at_max",
        "tau_G_ms_at_max", "n_strong_nodes_screen",
    ] + RATE_COLUMNS + [c for c in CONTROL_COLUMNS if c in df.columns]
    rejstrong[cols].to_csv(outdir / "03_rejected_strong_by_calibration.csv", index=False)
    rejstrong[cols].head(100).to_csv(outdir / "03A_nearest_100_rejected_strong.csv", index=False)

    rank_first = None if rejstrong.empty else int(rejstrong.calibration_rank.iloc[0])
    pct_first = None if rejstrong.empty else float(rejstrong.calibration_percentile.iloc[0])
    score_first = None if rejstrong.empty else float(rejstrong.calibration_score.iloc[0])
    r_first = None if rejstrong.empty else float(rejstrong.r_max.iloc[0])
    margin_q = {}
    if len(rejstrong):
        vals = rejstrong.score_margin_from_historical_cutoff.to_numpy(float)
        for q in [0, .01, .05, .10, .25, .50, .75, .90, .95, .99, 1.0]:
            margin_q[str(q)] = float(np.quantile(vals, q))
    summary = {
        "historical_cutoff": cutoff,
        "rejected_strong_n": int(len(rejstrong)),
        "nearest_rejected_strong_sample_id": None if rejstrong.empty else int(rejstrong.sample_id.iloc[0]),
        "nearest_rejected_strong_calibration_score": score_first,
        "nearest_rejected_strong_score_margin": None if rejstrong.empty else float(rejstrong.score_margin_from_historical_cutoff.iloc[0]),
        "nearest_rejected_strong_r_max": r_first,
        "first_rejected_strong_calibration_rank": rank_first,
        "first_rejected_strong_calibration_percentile": pct_first,
        "score_margin_quantiles_rejected_strong": margin_q,
    }
    (outdir / "03B_rejected_strong_boundary_summary.json").write_text(json.dumps(summary, indent=2))
    return summary


def witness_neighborhood(df: pd.DataFrame, outdir: Path, witness_id: int) -> dict:
    log("[6/8] Mapping the empirical neighborhood of witness 37318 in log-rate space")
    X = np.log10(df[RATE_COLUMNS].to_numpy(float))
    mu = X.mean(axis=0)
    sd = X.std(axis=0)
    Z = (X - mu) / np.where(sd > 0, sd, 1.0)
    wi = int(np.where(df.sample_id.to_numpy(int) == witness_id)[0][0])
    d = np.sqrt(np.sum((Z - Z[wi]) ** 2, axis=1))
    tmp = df.copy()
    tmp["standardized_log_rate_distance_to_witness"] = d
    tmp = tmp.sort_values(["standardized_log_rate_distance_to_witness", "sample_id"]).reset_index(drop=True)
    cols = [
        "sample_id", "standardized_log_rate_distance_to_witness", "accepted", "strong",
        "calibration_score", "score_margin_from_historical_cutoff", "calibration_percentile", "r_max",
    ] + RATE_COLUMNS
    tmp[cols].head(1000).to_csv(outdir / "04_witness_nearest_1000.csv", index=False)

    rows = []
    neighbors_only = tmp[tmp.sample_id != witness_id].reset_index(drop=True)
    for k in [10, 25, 50, 100, 250, 500, 1000]:
        sub = neighbors_only.head(k)
        rows.append({
            "k_nearest_excluding_witness": k,
            "strong_n": int(sub.strong.sum()),
            "strong_fraction": float(sub.strong.mean()),
            "accepted_n": int(sub.accepted.sum()),
            "accepted_fraction": float(sub.accepted.mean()),
            "both_strong_and_accepted_n": int((sub.strong & sub.accepted).sum()),
            "median_calibration_score": float(sub.calibration_score.median()),
            "minimum_calibration_score": float(sub.calibration_score.min()),
            "median_r_max": float(sub.r_max.median()),
            "maximum_r_max": float(sub.r_max.max()),
            "maximum_distance": float(sub.standardized_log_rate_distance_to_witness.max()),
        })
    summ = pd.DataFrame(rows)
    summ.to_csv(outdir / "04A_witness_neighborhood_summary.csv", index=False)
    result = {"witness_id": witness_id, "witness_distance_definition": "Euclidean distance after standardizing log10 of 12 rates over all 50,000 broad candidates", "neighborhoods": rows}
    (outdir / "04B_witness_neighborhood_summary.json").write_text(json.dumps(result, indent=2))
    return result


def robust_mad(x: np.ndarray) -> float:
    x = np.asarray(x, float)
    med = np.nanmedian(x)
    return float(1.4826 * np.nanmedian(np.abs(x - med)))


def control_observable_boundary(df: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    log("[7/8] Comparing control observables across accepted and near-boundary strong sets")
    metrics = [c for c in CONTROL_COLUMNS if c in df.columns]
    if not metrics:
        pd.DataFrame([{"status": "skipped", "reason": "control observable columns not present"}]).to_csv(outdir / "05_control_observable_boundary.csv", index=False)
        return pd.DataFrame()
    acc = df[df.accepted]
    rejstrong = df[(~df.accepted) & df.strong].sort_values("calibration_score")
    near100 = rejstrong.head(100)
    rows = []
    for c in metrics:
        a = pd.to_numeric(acc[c], errors="coerce").to_numpy(float)
        b = pd.to_numeric(rejstrong[c], errors="coerce").to_numpy(float)
        n = pd.to_numeric(near100[c], errors="coerce").to_numpy(float)
        allv = pd.to_numeric(df[c], errors="coerce").to_numpy(float)
        score = df.calibration_score.to_numpy(float)
        finite = np.isfinite(allv) & np.isfinite(score)
        rho = float(spearmanr(allv[finite], score[finite]).statistic) if finite.sum() > 5 else math.nan
        med_a = float(np.nanmedian(a)); mad_a = robust_mad(a)
        med_n = float(np.nanmedian(n)) if len(n) else math.nan
        med_b = float(np.nanmedian(b)) if len(b) else math.nan
        rows.append({
            "control_observable": c,
            "accepted_median": med_a,
            "accepted_IQR": float(np.nanquantile(a, .75) - np.nanquantile(a, .25)),
            "accepted_robust_MAD_scale": mad_a,
            "nearest100_rejected_strong_median": med_n,
            "all_rejected_strong_median": med_b,
            "nearest100_vs_accepted_robust_shift": (med_n - med_a) / mad_a if mad_a > 0 and np.isfinite(med_n) else math.nan,
            "all_rejected_strong_vs_accepted_robust_shift": (med_b - med_a) / mad_a if mad_a > 0 and np.isfinite(med_b) else math.nan,
            "spearman_rho_observable_vs_calibration_score_all": rho,
        })
    res = pd.DataFrame(rows)
    res.to_csv(outdir / "05_control_observable_boundary.csv", index=False)
    return res


def search_historical_calibration_sources(roots: list[Path], outdir: Path, self_script: Path) -> pd.DataFrame:
    log("[8/8] Searching server source tree for the exact historical calibration implementation")
    tokens = [
        "calibration_score", "accepted_control_calibration", "control_plateau_PO_140_250",
        "control_early_PO_140_200", "control_late_PO_200_500", "control_charge_PO_ms",
    ]
    rows = []
    visited = 0
    excluded_parts = {"venv", ".venv", "site-packages", ".git", "node_modules", "results_step_18_prior_geometry", "results_step_19_calibration_frontier"}
    for root in roots:
        try:
            iterator = root.rglob("*")
        except Exception:
            continue
        for p in iterator:
            if not p.is_file() or p == self_script:
                continue
            if any(part in excluded_parts for part in p.parts):
                continue
            if p.suffix.lower() not in {".py", ".sh", ".txt", ".md", ".r"}:
                continue
            try:
                if p.stat().st_size > 5_000_000:
                    continue
                text = p.read_text(errors="ignore")
            except Exception:
                continue
            visited += 1
            score = sum(text.count(t) for t in tokens)
            if score == 0:
                continue
            lines = text.splitlines()
            for i, line in enumerate(lines, start=1):
                hits = [t for t in tokens if t in line]
                if hits:
                    rows.append({"path": str(p), "line_number": i, "matched_tokens": "|".join(hits), "line": line.strip()[:1000], "file_match_score": score})
                    if len(rows) >= 500:
                        break
            if len(rows) >= 500:
                break
        if len(rows) >= 500:
            break
    res = pd.DataFrame(rows)
    if not res.empty:
        res = res.sort_values(["file_match_score", "path", "line_number"], ascending=[False, True, True])
    res.to_csv(outdir / "06_historical_calibration_source_candidates.csv", index=False)
    (outdir / "06A_source_search_summary.json").write_text(json.dumps({"source_files_scanned": visited, "matching_lines": int(len(res)), "interpretation": "This is provenance discovery only. Step19 v1.0 does not execute or approximate an unknown historical calibration function. Exact perturbation-cloud recalculation should be added only after the historical score implementation is identified and verified against the 50,000 frozen scores."}, indent=2))
    return res


def final_decision(df: pd.DataFrame, frontier: pd.DataFrame, feasibility: pd.DataFrame, boundary: dict, witness: dict, controls: pd.DataFrame, outdir: Path) -> None:
    selected = pd.read_csv(outdir / "01A_calibration_frontier_selected.csv")
    at10 = selected.iloc[(selected.calibration_top_percent - 10).abs().argmin()]
    at15 = selected.iloc[(selected.calibration_top_percent - 15).abs().argmin()]
    at20 = selected.iloc[(selected.calibration_top_percent - 20).abs().argmin()]
    at100 = selected.iloc[(selected.calibration_top_percent - 100).abs().argmin()]
    decisions = {}
    for target in TARGETS:
        rr = feasibility[(feasibility.target == target) & (feasibility.status == "supported")].copy()
        good = rr[rr.maximum_possible_ESS_fraction >= 0.10]
        decisions[target] = {
            "first_selected_calibration_percent_with_ESS_fraction_ge_0p10": None if good.empty else float(good.calibration_top_percent.iloc[0]),
            "best_ESS_fraction_over_selected_supports": None if rr.empty else float(rr.maximum_possible_ESS_fraction.max()),
        }

    # Data-driven qualitative code. No biological-probability interpretation.
    first_pct = boundary.get("first_rejected_strong_calibration_percentile")
    if first_pct is not None and first_pct <= 10.5:
        frontier_code = "strong_region_touches_or_lies_immediately_beyond_historical_calibration_boundary"
    elif first_pct is not None and first_pct <= 15:
        frontier_code = "strong_region_emerges_after_modest_relaxation_of_control_calibration"
    else:
        frontier_code = "strong_region_remains_separated_from_top_control_calibration_region"

    report = {
        "version": VERSION,
        "strong_threshold": STRONG_DEFAULT,
        "n_strong_precal_anywhere": int(df.strong.sum()),
        "n_strong_historical_accepted": int((df.strong & df.accepted).sum()),
        "historical_top10_strong_fraction": float(at10.strong_fraction),
        "top15_strong_fraction": float(at15.strong_fraction),
        "top20_strong_fraction": float(at20.strong_fraction),
        "all_broad_strong_fraction": float(at100.strong_fraction),
        "nearest_rejected_strong": boundary,
        "reweighting_support": decisions,
        "frontier_decision_code": frontier_code,
        "primary_experimental_target": "5/11",
        "sensitivity_target_after_excluding_extreme_responder": "4/10",
        "important_interpretation": "Fractions of sampled parameter sets are accessibility measures under the sampled ensemble, not estimates of biological cell probabilities.",
        "next_gate": "Recover and verify the exact historical control-calibration score implementation before continuous perturbation-cloud or physiological-prior fitting.",
    }
    (outdir / "07_scientific_decision.json").write_text(json.dumps(report, indent=2))

    txt = [
        "# Step 19 results: calibration-Braess compatibility frontier",
        "",
        f"- Historical accepted support: {int(df.accepted.sum())}/50000; strong within it: {int((df.strong & df.accepted).sum())}.",
        f"- Strong anywhere in the full broad ensemble: {int(df.strong.sum())}/50000 ({100*df.strong.mean():.3f}%).",
        f"- First rejected strong candidate enters at calibration percentile: {boundary.get('first_rejected_strong_calibration_percentile')}.",
        f"- Frontier decision: {frontier_code}.",
        "- Experimental incidence references are evaluated both as 5/11 (primary) and 4/10 (leave-extreme-responder-out sensitivity).",
        "- The strong threshold is unchanged in the sensitivity analysis because the removed point is the largest, not the smallest potentiating ratio.",
        "",
        "Interpretation rule: the calibration-percentile curves describe the geometry/accessibility of the sampled parameter ensemble. They are not biological prevalence estimates.",
        "",
        "Continuous witness perturbations are deliberately not assigned historical calibration labels in this version unless the exact historical score implementation is recovered. The source-search output lists candidate files for that provenance step.",
    ]
    (outdir / "README_RESULTS.md").write_text("\n".join(txt) + "\n")


def pack_results(outdir: Path) -> Path:
    zpath = outdir.parent / f"{outdir.name}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(outdir.rglob("*")):
            if p.is_file():
                zf.write(p, arcname=f"{outdir.name}/{p.relative_to(outdir)}")
    return zpath


def self_test() -> None:
    # Binary-reweighting ESS formula checks.
    ns, nn, p = 1, 4999, 5/11
    ws, wn = p/ns, (1-p)/nn
    ess = 1.0 / (ns*ws*ws + nn*wn*wn)
    assert 4.7 < ess < 5.0
    lo, hi = clopper_pearson(5, 11)
    assert 0 < lo < 5/11 < hi < 1
    # Ranking sanity.
    df = pd.DataFrame({"calibration_score": np.arange(100.0), "strong": [False]*90+[True]*10, "r_max": [1.0]*90+[2.0]*10})
    row = frontier_row(df, 10)
    assert row["n_included"] == 10 and row["strong_n"] == 0
    log("SELF-TEST PASS")


def main() -> None:
    ap = argparse.ArgumentParser(description="Step 19: calibration-Braess compatibility frontier")
    ap.add_argument("--step18-results", default=None, help="Step18 result directory or results_step_18_prior_geometry.zip")
    ap.add_argument("--precal-table", default=None, help="Historical Step10 all-samples table as CSV/CSV.GZ/Parquet or ZIP::member")
    ap.add_argument("--search-root", default=None, help="Additional root for input and historical-source discovery")
    ap.add_argument("--output", default="results_step_19_calibration_frontier")
    ap.add_argument("--strong-threshold", type=float, default=STRONG_DEFAULT)
    ap.add_argument("--witness-id", type=int, default=WITNESS_DEFAULT)
    ap.add_argument("--discover-only", action="store_true")
    ap.add_argument("--self-test", action="store_true")
    ap.add_argument("--skip-source-search", action="store_true")
    args = ap.parse_args()

    if args.self_test:
        self_test()
        return

    outdir = Path(args.output).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    roots = candidate_roots(args.search_root)
    step18 = args.step18_results or discover_step18(roots)
    precal = args.precal_table or discover_step10_all_samples(roots)
    if args.discover_only:
        log(f"step18 results: {step18}")
        log(f"step10 all-samples: {precal}")
        return
    if not step18:
        raise RuntimeError("Could not find Step18 results. Supply --step18-results.")
    if not precal:
        raise RuntimeError("Could not find historical Step10 all-samples table. Supply --precal-table; ZIP::member syntax is supported.")

    log(f"Step18 results: {step18}")
    log(f"Step10 all-samples: {precal}")
    df = prepare_inputs(step18, precal, outdir, args.strong_threshold, args.witness_id)
    frontier = calibration_frontier(df, outdir)
    feasibility = reweight_feasibility(df, outdir)
    boundary = rejected_strong_boundary(df, outdir)
    witness = witness_neighborhood(df, outdir, args.witness_id)
    controls = control_observable_boundary(df, outdir)
    if args.skip_source_search:
        pd.DataFrame([{"status": "skipped_by_user"}]).to_csv(outdir / "06_historical_calibration_source_candidates.csv", index=False)
    else:
        search_historical_calibration_sources(roots, outdir, Path(__file__).resolve())
    final_decision(df, frontier, feasibility, boundary, witness, controls, outdir)
    zpath = pack_results(outdir)
    log(f"DONE: {zpath}")


if __name__ == "__main__":
    main()
