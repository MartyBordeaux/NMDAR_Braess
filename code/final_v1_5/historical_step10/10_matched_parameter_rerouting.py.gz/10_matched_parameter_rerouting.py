#!/usr/bin/env python3
"""
Step 10: matched-parameter test of intrareceptor probability-flow rerouting.

The control and Ro25 simulations share every kinetic parameter, glutamate
forcing, conductance, initial condition, time grid, and observation rule.
Ro25 changes only the explicitly named graph operation for each mechanism.

This script tests topological possibility. It does not fit a unique molecular
parameter set and it does not prove that Ro25 uses the tested rerouting rule.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import platform
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from numba import get_num_threads, njit, prange, set_num_threads
from scipy.stats import beta, binom, qmc, spearmanr


SCRIPT_VERSION = "1.0.0"
STATE_NAMES = ["P0", "P1A", "P1B", "P2", "PD1", "PD2", "PC1", "PC2", "PO", "PRo"]

# Parameter columns in the numeric matrix passed to numba.
P_KON_A = 0
P_KON_B = 1
P_KOFF_A = 2
P_KOFF_B = 3
P_KF_PLUS = 4
P_KS_PLUS = 5
P_KF_MINUS = 6
P_KS_MINUS = 7
P_KD1_PLUS = 8
P_KD1_MINUS = 9
P_KD2_PLUS = 10
P_KD2_MINUS = 11
P_PULSE_AMP = 12
P_TAU_G = 13
P_RO_RESIDUAL = 14
P_K_TRANSFER = 15
P_COUNT = 16

PARAMETER_NAMES = [
    "kon_A_per_ms",
    "kon_B_per_ms",
    "koff_A_per_ms",
    "koff_B_per_ms",
    "kf_plus_per_ms",
    "ks_plus_per_ms",
    "kf_minus_per_ms",
    "ks_minus_per_ms",
    "kd1_plus_per_ms",
    "kd1_minus_per_ms",
    "kd2_plus_per_ms",
    "kd2_minus_per_ms",
    "pulse_amplitude_au",
    "glutamate_tau_ms",
    "ro25_B_residual",
    "ro25_transfer_per_ms",
]

# Codes are stable and recorded in every result.
MECHANISMS = {
    "control": 0,
    "branch_reroute": 1,
    "state_transfer": 2,
    "b_edge_attenuation": 3,
    "legacy_sink": 4,
    "presentation_collapse": 5,
    "single_B_entry_attenuation": 6,
}
MECH_CONTROL = 0
MECH_BRANCH_REROUTE = 1
MECH_STATE_TRANSFER = 2
MECH_B_EDGE_ATTENUATION = 3
MECH_LEGACY_SINK = 4
MECH_PRESENTATION_COLLAPSE = 5
MECH_SINGLE_B_ENTRY_ATTENUATION = 6
PRIMARY_MECHANISMS = [
    "single_B_entry_attenuation",
    "branch_reroute",
    "state_transfer",
    "b_edge_attenuation",
    "legacy_sink",
    "presentation_collapse",
]

METRIC_NAMES = [
    "peak_PO",
    "plateau_PO_140_250",
    "late_PO_200_500",
    "charge_PO_ms",
    "early_PO_140_200",
    "mass_error_max",
    "minimum_state",
    "valid",
]
METRIC_COUNT = 8


@dataclass(frozen=True)
class PriorSpec:
    name: str
    lower: np.ndarray
    upper: np.ndarray
    log_scaled: np.ndarray


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Matched-parameter intrareceptor rerouting test"
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        default=Path.home() / "nmda" / "IV_NMDA",
        help="Raw-data directory, used only for provenance; no pairing is reconstructed.",
    )
    parser.add_argument(
        "--targets",
        default="auto",
        help=(
            "experimental_targets.json, results_step4.zip, extracted step-4 "
            "directory, or 'auto'"
        ),
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path.home() / "nmda" / "results" / "10_matched_rerouting",
    )
    parser.add_argument("--samples", type=int, default=10000)
    parser.add_argument("--accepted", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260728)
    parser.add_argument("--dt-ms", type=float, default=0.05)
    parser.add_argument("--duration-ms", type=float, default=600.0)
    parser.add_argument("--pulse-count", type=int, default=25)
    parser.add_argument("--pulse-interval-ms", type=float, default=5.1)
    parser.add_argument(
        "--priors",
        default="reference,broad",
        help="Comma-separated subset of reference,broad",
    )
    parser.add_argument(
        "--braess-threshold",
        type=float,
        default=1.0,
        help="Strict plateau Ro25/control threshold.",
    )
    parser.add_argument(
        "--robust-threshold",
        type=float,
        default=1.05,
        help="Robust plateau Ro25/control threshold.",
    )
    parser.add_argument("--threads", type=int, default=0)
    parser.add_argument(
        "--self-test",
        action="store_true",
        help="Run conservation, identity and directional negative-control tests.",
    )
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def packaged_targets_path() -> Path:
    return Path(__file__).resolve().parent / "config" / "default_experimental_targets.json"


def _read_json_from_zip(path: Path) -> tuple[dict[str, Any], str]:
    with zipfile.ZipFile(path) as archive:
        candidates = [
            name
            for name in archive.namelist()
            if name.endswith("experimental_targets.json")
        ]
        if not candidates:
            raise FileNotFoundError(
                f"No experimental_targets.json inside {path}"
            )
        name = sorted(candidates, key=len)[0]
        return json.loads(archive.read(name).decode("utf-8")), f"{path}::{name}"


def load_targets(spec: str) -> tuple[dict[str, Any], str, str | None]:
    if spec != "auto":
        path = Path(spec).expanduser().resolve()
        if path.is_file() and path.suffix.lower() == ".zip":
            data, source = _read_json_from_zip(path)
            return data, source, sha256_file(path)
        if path.is_file():
            return json.loads(path.read_text(encoding="utf-8")), str(path), sha256_file(path)
        if path.is_dir():
            candidates = list(path.rglob("experimental_targets.json"))
            if not candidates:
                raise FileNotFoundError(
                    f"No experimental_targets.json below {path}"
                )
            selected = sorted(candidates, key=lambda x: len(str(x)))[0]
            return (
                json.loads(selected.read_text(encoding="utf-8")),
                str(selected),
                sha256_file(selected),
            )
        raise FileNotFoundError(path)

    candidates = [
        Path.home() / "nmda" / "results" / "04_model_comparison" / "experimental_targets.json",
        Path.home() / "nmda" / "results_step4.zip",
        Path.home() / "nmda" / "results_step4_tables.zip",
        packaged_targets_path(),
    ]
    for path in candidates:
        if not path.exists():
            continue
        if path.suffix.lower() == ".zip":
            try:
                data, source = _read_json_from_zip(path)
                return data, source, sha256_file(path)
            except FileNotFoundError:
                continue
        return (
            json.loads(path.read_text(encoding="utf-8")),
            str(path),
            sha256_file(path),
        )
    raise FileNotFoundError("No experimental target source was found")


def prior_specs() -> dict[str, PriorSpec]:
    # Effective per-ms rates. These are support ranges for a topology test,
    # not posterior intervals and not direct biochemical estimates.
    reference_center = np.array(
        [
            0.80, 0.35, 0.30, 0.10,
            2.50, 0.45, 0.45, 0.45,
            0.25, 0.09, 0.55, 0.01,
            0.70, 10.0, 0.05, 0.40,
        ],
        dtype=float,
    )
    ref_lower = reference_center.copy()
    ref_upper = reference_center.copy()
    ref_lower[:14] *= 0.35
    ref_upper[:14] *= 2.85
    ref_lower[P_RO_RESIDUAL], ref_upper[P_RO_RESIDUAL] = 0.0, 0.20
    ref_lower[P_K_TRANSFER], ref_upper[P_K_TRANSFER] = 0.01, 2.0

    broad_lower = np.array(
        [
            0.02, 0.01, 0.005, 0.001,
            0.10, 0.01, 0.01, 0.01,
            0.005, 0.001, 0.005, 0.0003,
            0.10, 3.0, 0.0, 0.001,
        ],
        dtype=float,
    )
    broad_upper = np.array(
        [
            3.0, 3.0, 2.0, 1.0,
            4.0, 2.0, 2.0, 2.0,
            2.0, 1.0, 2.0, 0.25,
            2.0, 30.0, 0.35, 4.0,
        ],
        dtype=float,
    )
    log_scaled = np.ones(P_COUNT, dtype=bool)
    log_scaled[P_RO_RESIDUAL] = False
    return {
        "reference": PriorSpec("reference", ref_lower, ref_upper, log_scaled),
        "broad": PriorSpec("broad", broad_lower, broad_upper, log_scaled),
    }


def latin_hypercube(spec: PriorSpec, count: int, seed: int) -> np.ndarray:
    design = qmc.LatinHypercube(d=P_COUNT, seed=seed).random(count)
    values = np.empty_like(design)
    for col in range(P_COUNT):
        lo = spec.lower[col]
        hi = spec.upper[col]
        if spec.log_scaled[col]:
            values[:, col] = np.exp(np.log(lo) + design[:, col] * np.log(hi / lo))
        else:
            values[:, col] = lo + design[:, col] * (hi - lo)
    return values


@njit(cache=True)
def rhs(
    state: np.ndarray,
    g: float,
    p: np.ndarray,
    mechanism: int,
) -> np.ndarray:
    p0, p1a, p1b, p2, pd1, pd2, pc1, pc2, po, pro = state

    kon_a = p[P_KON_A]
    kon_b = p[P_KON_B]
    koff_a = p[P_KOFF_A]
    koff_b = p[P_KOFF_B]
    kfp = p[P_KF_PLUS]
    ksp = p[P_KS_PLUS]
    kfm = p[P_KF_MINUS]
    ksm = p[P_KS_MINUS]
    kd1p = p[P_KD1_PLUS]
    kd1m = p[P_KD1_MINUS]
    kd2p = p[P_KD2_PLUS]
    kd2m = p[P_KD2_MINUS]
    residual = p[P_RO_RESIDUAL]
    transfer_rate = p[P_K_TRANSFER]

    if mechanism == MECH_PRESENTATION_COLLAPSE:
        kon_eff = math.sqrt(kon_a * kon_b)
        koff_eff = math.sqrt(koff_a * koff_b)
        f0a = 2.0 * kon_eff * g * p0
        r_a = koff_eff * p1a
        f0b = 0.0
        r_b = 0.0
        f_ab = kon_eff * g * p1a
        r_2a = 2.0 * koff_eff * p2
        f_ba = 0.0
        r_2b = 0.0
    else:
        f0a = kon_a * g * p0
        f0b_base = kon_b * g * p0
        if mechanism == MECH_BRANCH_REROUTE:
            f0a += (1.0 - residual) * f0b_base
            f0b = residual * f0b_base
        elif mechanism == MECH_B_EDGE_ATTENUATION or mechanism == MECH_SINGLE_B_ENTRY_ATTENUATION:
            f0b = residual * f0b_base
        else:
            f0b = f0b_base
        r_a = koff_a * p1a
        r_b = koff_b * p1b
        f_ab = kon_b * g * p1a
        if mechanism == MECH_B_EDGE_ATTENUATION:
            f_ab *= residual
        r_2a = koff_b * p2
        f_ba = kon_a * g * p1b
        r_2b = koff_a * p2

    transfer = 0.0
    if mechanism == MECH_STATE_TRANSFER:
        transfer = transfer_rate * p1b
    sink = 0.0
    if mechanism == MECH_LEGACY_SINK:
        sink = transfer_rate * p1b

    f_d1 = kd1p * p2
    r_d1 = kd1m * pd1
    f_d2 = kd2p * p2
    r_d2 = kd2m * pd2
    f_c1 = kfp * p2
    r_c1 = kfm * pc1
    f_c2 = ksp * p2
    r_c2 = ksm * pc2
    c1_o = ksp * pc1
    o_c1 = ksm * po
    c2_o = kfp * pc2
    o_c2 = kfm * po

    out = np.empty(10, dtype=np.float64)
    out[0] = -f0a - f0b + r_a + r_b
    out[1] = f0a - r_a - f_ab + r_2a + transfer
    out[2] = f0b - r_b - f_ba + r_2b - transfer - sink
    out[3] = (
        f_ab + f_ba - r_2a - r_2b
        - f_d1 - f_d2 - f_c1 - f_c2
        + r_d1 + r_d2 + r_c1 + r_c2
    )
    out[4] = f_d1 - r_d1
    out[5] = f_d2 - r_d2
    out[6] = f_c1 - r_c1 - c1_o + o_c1
    out[7] = f_c2 - r_c2 - c2_o + o_c2
    out[8] = c1_o + c2_o - o_c1 - o_c2
    out[9] = sink
    return out


@njit(cache=True)
def simulate_one(
    p: np.ndarray,
    mechanism: int,
    dt_ms: float,
    duration_ms: float,
    pulse_count: int,
    pulse_interval_ms: float,
) -> np.ndarray:
    steps = int(round(duration_ms / dt_ms))
    state = np.zeros(10, dtype=np.float64)
    state[0] = 1.0
    g = 0.0
    decay = math.exp(-dt_ms / p[P_TAU_G])
    next_pulse = 0

    peak = 0.0
    plateau = 0.0
    plateau_n = 0
    late = 0.0
    late_n = 0
    early = 0.0
    early_n = 0
    charge = 0.0
    mass_error = 0.0
    minimum_state = 0.0

    for step in range(steps + 1):
        t = step * dt_ms
        while (
            next_pulse < pulse_count
            and t + 0.5 * dt_ms >= next_pulse * pulse_interval_ms
        ):
            g += p[P_PULSE_AMP]
            next_pulse += 1
        g_eff = g / (1.0 + g)

        po = state[8]
        if po > peak:
            peak = po
        charge += po * dt_ms
        if 140.0 <= t < 250.0:
            plateau += po
            plateau_n += 1
        if 200.0 <= t < min(500.0, duration_ms + dt_ms):
            late += po
            late_n += 1
        if 140.0 <= t < 200.0:
            early += po
            early_n += 1

        mass = 0.0
        for idx in range(10):
            mass += state[idx]
            if state[idx] < minimum_state:
                minimum_state = state[idx]
        err = abs(mass - 1.0)
        if err > mass_error:
            mass_error = err

        if step == steps:
            break

        # Explicit midpoint (second-order Runge-Kutta), no clipping or
        # renormalization. Invalid trajectories are rejected downstream.
        d1 = rhs(state, g_eff, p, mechanism)
        midpoint = state + 0.5 * dt_ms * d1
        g_next = g * decay
        g_next_eff = g_next / (1.0 + g_next)
        dmid = rhs(midpoint, 0.5 * (g_eff + g_next_eff), p, mechanism)
        state = state + dt_ms * dmid
        g = g_next

    out = np.empty(METRIC_COUNT, dtype=np.float64)
    out[0] = peak
    out[1] = plateau / max(1, plateau_n)
    out[2] = late / max(1, late_n)
    out[3] = charge
    out[4] = early / max(1, early_n)
    out[5] = mass_error
    out[6] = minimum_state
    out[7] = 1.0 if mass_error < 1e-6 and minimum_state > -1e-7 else 0.0
    return out


@njit(parallel=True, cache=True)
def simulate_ensemble(
    parameters: np.ndarray,
    mechanism: int,
    dt_ms: float,
    duration_ms: float,
    pulse_count: int,
    pulse_interval_ms: float,
) -> np.ndarray:
    count = parameters.shape[0]
    output = np.empty((count, METRIC_COUNT), dtype=np.float64)
    for index in prange(count):
        output[index, :] = simulate_one(
            parameters[index, :],
            mechanism,
            dt_ms,
            duration_ms,
            pulse_count,
            pulse_interval_ms,
        )
    return output


@njit(cache=True)
def simulate_trace(
    p: np.ndarray,
    mechanism: int,
    dt_ms: float,
    duration_ms: float,
    pulse_count: int,
    pulse_interval_ms: float,
    save_every_ms: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    steps = int(round(duration_ms / dt_ms))
    save_stride = max(1, int(round(save_every_ms / dt_ms)))
    save_count = steps // save_stride + 1
    times = np.empty(save_count, dtype=np.float64)
    states = np.empty((save_count, 10), dtype=np.float64)
    glutamate = np.empty(save_count, dtype=np.float64)

    state = np.zeros(10, dtype=np.float64)
    state[0] = 1.0
    g = 0.0
    decay = math.exp(-dt_ms / p[P_TAU_G])
    next_pulse = 0
    save_index = 0

    for step in range(steps + 1):
        t = step * dt_ms
        while (
            next_pulse < pulse_count
            and t + 0.5 * dt_ms >= next_pulse * pulse_interval_ms
        ):
            g += p[P_PULSE_AMP]
            next_pulse += 1
        g_eff = g / (1.0 + g)
        if step % save_stride == 0:
            times[save_index] = t
            states[save_index, :] = state
            glutamate[save_index] = g_eff
            save_index += 1
        if step == steps:
            break
        d1 = rhs(state, g_eff, p, mechanism)
        midpoint = state + 0.5 * dt_ms * d1
        g_next = g * decay
        g_next_eff = g_next / (1.0 + g_next)
        dmid = rhs(midpoint, 0.5 * (g_eff + g_next_eff), p, mechanism)
        state = state + dt_ms * dmid
        g = g_next
    return times, states, glutamate


def metrics_frame(metrics: np.ndarray, prefix: str) -> pd.DataFrame:
    return pd.DataFrame(
        {f"{prefix}_{name}": metrics[:, idx] for idx, name in enumerate(METRIC_NAMES)}
    )


def safe_ratio(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    out = np.full_like(numerator, np.nan, dtype=float)
    mask = np.isfinite(numerator) & np.isfinite(denominator) & (denominator > 1e-12)
    out[mask] = numerator[mask] / denominator[mask]
    return out


def calibration_score(
    control: pd.DataFrame, targets: dict[str, Any]
) -> np.ndarray:
    cal = targets["calibration"]
    plateau = control["control_plateau_PO_140_250"].to_numpy()
    early = control["control_early_PO_140_200"].to_numpy()
    late = control["control_late_PO_200_500"].to_numpy()
    charge = control["control_charge_PO_ms"].to_numpy()
    valid = control["control_valid"].to_numpy() > 0.5

    early_ratio = safe_ratio(early, plateau)
    late_ratio = safe_ratio(late, plateau)
    charge_ratio = safe_ratio(charge, plateau)

    def log_term(values: np.ndarray, target: float, tolerance: float) -> np.ndarray:
        result = np.full_like(values, np.inf)
        mask = (values > 0) & np.isfinite(values)
        result[mask] = (np.log(values[mask] / target) / tolerance) ** 2
        return result

    score = (
        log_term(
            early_ratio,
            float(cal["early_over_primary_median"]),
            float(cal.get("early_over_primary_log_tolerance", 0.35)),
        )
        + log_term(
            late_ratio,
            float(cal["late_over_primary_median"]),
            float(cal.get("late_over_primary_log_tolerance", 0.35)),
        )
        + 0.5
        * log_term(
            charge_ratio,
            float(cal["charge_over_primary_ms_median"]),
            float(cal.get("charge_over_primary_log_tolerance", 0.5)),
        )
    )
    score[~valid] = np.inf
    return score


def clopper_pearson(k: int, n: int, alpha: float = 0.05) -> tuple[float, float]:
    if n <= 0:
        return float("nan"), float("nan")
    lo = 0.0 if k == 0 else float(beta.ppf(alpha / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alpha / 2, k + 1, n - k))
    return lo, hi


def model_fraction_interval(k: int, n: int) -> tuple[float, float]:
    # Jeffreys interval quantifies Monte Carlo uncertainty only.
    return (
        float(beta.ppf(0.025, k + 0.5, n - k + 0.5)),
        float(beta.ppf(0.975, k + 0.5, n - k + 0.5)),
    )


def summarize_mechanism(
    frame: pd.DataFrame,
    prior: str,
    mechanism: str,
    accepted_mask: np.ndarray,
    strict_threshold: float,
    robust_threshold: float,
    experimental_k: int,
    experimental_n: int,
) -> dict[str, Any]:
    ratio_col = f"{mechanism}_plateau_ratio"
    valid_col = f"{mechanism}_valid_pair"
    mask = accepted_mask & frame[valid_col].to_numpy(dtype=bool)
    values = frame.loc[mask, ratio_col].to_numpy(dtype=float)
    strict_k = int(np.sum(values > strict_threshold))
    robust_k = int(np.sum(values > robust_threshold))
    n = len(values)
    strict_fraction = strict_k / n if n else float("nan")
    robust_fraction = robust_k / n if n else float("nan")
    strict_lo, strict_hi = model_fraction_interval(strict_k, n) if n else (np.nan, np.nan)
    robust_lo, robust_hi = model_fraction_interval(robust_k, n) if n else (np.nan, np.nan)
    exp_fraction = experimental_k / experimental_n if experimental_n else np.nan
    return {
        "prior": prior,
        "mechanism": mechanism,
        "accepted_valid_n": n,
        "strict_threshold": strict_threshold,
        "strict_braess_n": strict_k,
        "strict_braess_fraction": strict_fraction,
        "strict_mc_ci_low": strict_lo,
        "strict_mc_ci_high": strict_hi,
        "robust_threshold": robust_threshold,
        "robust_braess_n": robust_k,
        "robust_braess_fraction": robust_fraction,
        "robust_mc_ci_low": robust_lo,
        "robust_mc_ci_high": robust_hi,
        "plateau_ratio_median": float(np.nanmedian(values)) if n else np.nan,
        "plateau_ratio_q025": float(np.nanquantile(values, 0.025)) if n else np.nan,
        "plateau_ratio_q975": float(np.nanquantile(values, 0.975)) if n else np.nan,
        "experimental_responder_k": experimental_k,
        "experimental_responder_n": experimental_n,
        "experimental_responder_fraction": exp_fraction,
        "binomial_probability_exact_k_given_model_fraction": (
            float(binom.pmf(experimental_k, experimental_n, strict_fraction))
            if n and np.isfinite(strict_fraction)
            else np.nan
        ),
        "binomial_log_likelihood_of_observed_k": (
            float(binom.logpmf(experimental_k, experimental_n, strict_fraction))
            if n and 0 < strict_fraction < 1
            else np.nan
        ),
    }


def select_examples(
    frame: pd.DataFrame,
    accepted_mask: np.ndarray,
    prior: str,
) -> list[tuple[str, int, str]]:
    selected: list[tuple[str, int, str]] = []
    for mechanism in [
        "single_B_entry_attenuation",
        "branch_reroute",
        "state_transfer",
        "presentation_collapse",
    ]:
        ratio_col = f"{mechanism}_plateau_ratio"
        valid_col = f"{mechanism}_valid_pair"
        mask = accepted_mask & frame[valid_col].to_numpy(dtype=bool)
        candidates = frame.loc[mask, ["sample_id", ratio_col]].dropna()
        if candidates.empty:
            continue
        strong = int(candidates.sort_values(ratio_col).iloc[-1]["sample_id"])
        selected.append((prior, strong, mechanism))
    return selected


def make_trace_tables(
    all_frames: dict[str, pd.DataFrame],
    all_parameters: dict[str, np.ndarray],
    selections: list[tuple[str, int, str]],
    dt_ms: float,
    duration_ms: float,
    pulse_count: int,
    pulse_interval_ms: float,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    trace_records: list[dict[str, Any]] = []
    flow_records: list[dict[str, Any]] = []

    for prior, sample_id, mechanism in selections:
        p = all_parameters[prior][sample_id]
        for condition, code in [
            ("control", MECHANISMS["control"]),
            ("Ro25", MECHANISMS[mechanism]),
        ]:
            times, states, glutamate = simulate_trace(
                p,
                code,
                dt_ms,
                duration_ms,
                pulse_count,
                pulse_interval_ms,
                1.0,
            )
            for row_idx, t in enumerate(times):
                record: dict[str, Any] = {
                    "prior": prior,
                    "sample_id": sample_id,
                    "mechanism": mechanism,
                    "condition": condition,
                    "time_ms": t,
                    "glutamate_effective": glutamate[row_idx],
                    "current_abs_au": states[row_idx, 8],
                }
                for state_idx, name in enumerate(STATE_NAMES):
                    record[name] = states[row_idx, state_idx]
                trace_records.append(record)

            # Flow accounting on the saved 1-ms grid. It is explanatory and
            # separate from the higher-resolution endpoint calculation.
            p0 = states[:, 0]
            p1a = states[:, 1]
            p1b = states[:, 2]
            p2 = states[:, 3]
            pc1 = states[:, 6]
            pc2 = states[:, 7]
            po = states[:, 8]
            g = glutamate
            dt_save = float(np.median(np.diff(times)))
            f0a_base = p[P_KON_A] * g * p0
            f0b_base = p[P_KON_B] * g * p0
            rerouted = np.zeros_like(g)
            retained_at_P0_from_B_attenuation = np.zeros_like(g)
            state_transfer = np.zeros_like(g)
            sink = np.zeros_like(g)
            f0a_actual = f0a_base.copy()
            f0b_actual = f0b_base.copy()
            if condition == "Ro25" and mechanism == "branch_reroute":
                rerouted = (1.0 - p[P_RO_RESIDUAL]) * f0b_base
                f0a_actual = f0a_base + rerouted
                f0b_actual = p[P_RO_RESIDUAL] * f0b_base
            if condition == "Ro25" and mechanism == "single_B_entry_attenuation":
                retained_at_P0_from_B_attenuation = (
                    (1.0 - p[P_RO_RESIDUAL]) * f0b_base
                )
                f0b_actual = p[P_RO_RESIDUAL] * f0b_base
            if condition == "Ro25" and mechanism == "b_edge_attenuation":
                f0b_actual = p[P_RO_RESIDUAL] * f0b_base
            if condition == "Ro25" and mechanism == "state_transfer":
                state_transfer = p[P_K_TRANSFER] * p1b
            if condition == "Ro25" and mechanism == "legacy_sink":
                sink = p[P_K_TRANSFER] * p1b
            flows = {
                "A_entry_base": f0a_base,
                "B_entry_base": f0b_base,
                "A_entry_actual": f0a_actual,
                "B_entry_actual": f0b_actual,
                "rerouted_B_entry_to_A": rerouted,
                "B_entry_hazard_retained_at_P0": retained_at_P0_from_B_attenuation,
                "P1B_to_P1A_transfer": state_transfer,
                "P1B_to_sink": sink,
                "P1A_to_P2": p[P_KON_B] * g * p1a,
                "P1B_to_P2": p[P_KON_A] * g * p1b,
                "opening_flux": p[P_KS_PLUS] * pc1 + p[P_KF_PLUS] * pc2,
                "closing_flux": (p[P_KS_MINUS] + p[P_KF_MINUS]) * po,
                "P2_occupancy_integral": p2,
                "open_occupancy_integral": po,
            }
            for flow_name, values in flows.items():
                flow_records.append(
                    {
                        "prior": prior,
                        "sample_id": sample_id,
                        "mechanism": mechanism,
                        "condition": condition,
                        "quantity": flow_name,
                        "time_integral": float(np.trapezoid(values, dx=dt_save)),
                        "units": "probability" if "flux" in flow_name or "entry" in flow_name or "transfer" in flow_name or "sink" in flow_name else "probability_ms",
                    }
                )
    return pd.DataFrame(trace_records), pd.DataFrame(flow_records)


def parameter_sensitivity(
    frame: pd.DataFrame,
    accepted_mask: np.ndarray,
) -> pd.DataFrame:
    records: list[dict[str, Any]] = []
    for mechanism in PRIMARY_MECHANISMS:
        ratio_col = f"{mechanism}_plateau_ratio"
        valid_col = f"{mechanism}_valid_pair"
        mask = accepted_mask & frame[valid_col].to_numpy(dtype=bool)
        for parameter in PARAMETER_NAMES:
            x = frame.loc[mask, parameter].to_numpy(dtype=float)
            y = frame.loc[mask, ratio_col].to_numpy(dtype=float)
            finite = np.isfinite(x) & np.isfinite(y)
            if finite.sum() < 10 or np.unique(x[finite]).size < 3:
                rho, pvalue = np.nan, np.nan
            else:
                rho, pvalue = spearmanr(x[finite], y[finite])
            records.append(
                {
                    "prior": frame["prior"].iloc[0],
                    "mechanism": mechanism,
                    "parameter": parameter,
                    "spearman_rho": rho,
                    "p_unadjusted": pvalue,
                    "n": int(finite.sum()),
                }
            )
    return pd.DataFrame(records)


def data_provenance(path: Path) -> dict[str, Any]:
    path = path.expanduser()
    if not path.exists():
        return {"path": str(path), "exists": False, "file_count": 0}
    files = sorted(item for item in path.rglob("*") if item.is_file())
    names_hash = hashlib.sha256()
    for item in files:
        names_hash.update(str(item.relative_to(path)).encode("utf-8", "replace"))
        names_hash.update(b"\0")
        names_hash.update(str(item.stat().st_size).encode("ascii"))
        names_hash.update(b"\n")
    return {
        "path": str(path.resolve()),
        "exists": True,
        "file_count": len(files),
        "relative_name_size_sha256": names_hash.hexdigest(),
        "note": "Raw files were not re-paired or re-fitted in this topology test.",
    }


def run_self_test() -> None:
    spec = prior_specs()["reference"]
    p = latin_hypercube(spec, 12, 17)
    p[:, P_RO_RESIDUAL] = 1.0
    control = simulate_ensemble(p, MECHANISMS["control"], 0.02, 100.0, 5, 5.0)
    identity = simulate_ensemble(p, MECHANISMS["branch_reroute"], 0.02, 100.0, 5, 5.0)
    if not np.allclose(control[:, :5], identity[:, :5], rtol=2e-5, atol=2e-8):
        raise AssertionError("Residual=1 branch-reroute identity test failed")
    single_edge_identity = simulate_ensemble(
        p, MECHANISMS["single_B_entry_attenuation"], 0.02, 100.0, 5, 5.0
    )
    if not np.allclose(
        control[:, :5], single_edge_identity[:, :5], rtol=2e-5, atol=2e-8
    ):
        raise AssertionError("Residual=1 single-edge identity test failed")
    if np.any(control[:, 7] < 0.5):
        raise AssertionError("Control conservation test failed")

    # A sink must not create more open-state charge than the matched control.
    sink = simulate_ensemble(p, MECHANISMS["legacy_sink"], 0.02, 100.0, 5, 5.0)
    if np.any(sink[:, 3] > control[:, 3] * (1.0 + 1e-5)):
        raise AssertionError("Legacy sink directional test failed")

    # Step-size convergence on the same parameter vectors.
    coarse = simulate_ensemble(p, MECHANISMS["state_transfer"], 0.04, 100.0, 5, 5.0)
    fine = simulate_ensemble(p, MECHANISMS["state_transfer"], 0.02, 100.0, 5, 5.0)
    rel = np.abs(coarse[:, 3] - fine[:, 3]) / np.maximum(fine[:, 3], 1e-12)
    if np.nanmax(rel) > 0.03:
        raise AssertionError(f"Step-size convergence failed: max relative error={rel.max():.4g}")
    print("SELF-TEST PASSED")


def write_report(
    out_dir: Path,
    summary: pd.DataFrame,
    targets: dict[str, Any],
    target_source: str,
    run_summary: dict[str, Any],
) -> None:
    validation = targets["validation"]
    k = int(validation["responder_like_count"])
    n = int(validation["responder_like_n"])
    exp_lo, exp_hi = clopper_pearson(k, n)
    lines = [
        "# Step 10: matched-parameter intrareceptor rerouting",
        "",
        "## Question",
        "",
        "Can a single extrasynaptic NMDA-receptor kinetic graph show a larger "
        "absolute current after a Ro25-like graph perturbation when control and "
        "Ro25 share the same parameters and glutamate train?",
        "",
        "This is a possibility test, not proof of the mechanism.",
        "",
        "## Hard constraints enforced",
        "",
        "- one extrasynaptic receptor graph; no synaptic–extrasynaptic coupling;",
        "- no competition for glutamate;",
        "- identical kinetic parameters, glutamate forcing, conductance, baseline, "
        "initial condition, time grid and endpoint definition in control and Ro25;",
        "- no per-trace maximum normalization;",
        "- Ro25 changes only the named graph operation;",
        "- absolute open probability is used as the current proxy;",
        "- probability conservation and time-step convergence are audited.",
        "",
        "## Mechanisms",
        "",
        "- `branch_reroute`: the blocked fraction of the `P0→P1B` entry flux is "
        "redirected to `P0→P1A`.",
        "- `single_B_entry_attenuation`: only the `P0→P1B` edge is attenuated; "
        "probability remaining in `P0` can subsequently use the A route.",
        "- `state_transfer`: Ro25 adds the single transition `P1B→P1A`.",
        "- `b_edge_attenuation`: both B-association edges are attenuated without "
        "an explicit transfer edge; time-windowed enhancement is not assumed impossible.",
        "- `legacy_sink`: `P1B→PRo` absorbing sink from the old code.",
        "- `presentation_collapse`: sensitivity analysis matching the presentation's "
        "AB-to-effective-two-step topology, with effective rates fixed as geometric "
        "means of the same A/B parameters.",
        "",
        "## Experimental frequency",
        "",
        f"The descriptive experimental count is {k}/{n} = {k/n:.3f}; exact 95% "
        f"binomial interval [{exp_lo:.3f}, {exp_hi:.3f}]. The interval is wide, and "
        "the model fraction is prior-dependent. Therefore frequency agreement is "
        "reported as compatibility, not estimation or validation.",
        "",
        f"Target source: `{target_source}`.",
        "",
        "## Accepted-ensemble results",
        "",
    ]
    for _, row in summary.iterrows():
        lines.append(
            f"- {row['prior']} / {row['mechanism']}: "
            f"P(ratio>{row['strict_threshold']:.3g})="
            f"{row['strict_braess_fraction']:.3f}; "
            f"P(ratio>{row['robust_threshold']:.3g})="
            f"{row['robust_braess_fraction']:.3f}; "
            f"median ratio={row['plateau_ratio_median']:.3f}."
        )
    lines += [
        "",
        "## Interpretation rule",
        "",
        "A reproducible ratio above one for a mass-conserving rerouting mechanism "
        "establishes that the original intrareceptor idea is mathematically possible "
        "under matched parameters. It does not show that Ro25 causes that specific "
        "state transition in a native receptor.",
        "",
        "A positive result only under `presentation_collapse` means that the result "
        "depends on replacing the ligand-binding topology, rather than on deleting "
        "one edge. A positive result only under free blocked/control parameters would "
        "not pass this test.",
        "",
        "## Provenance",
        "",
        "```json",
        json.dumps(run_summary, ensure_ascii=False, indent=2),
        "```",
        "",
    ]
    (out_dir / "analysis_report.md").write_text(
        "\n".join(lines), encoding="utf-8"
    )


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if args.samples < 500:
        raise ValueError("--samples must be at least 500")
    if args.accepted < 100 or args.accepted >= args.samples:
        raise ValueError("--accepted must be >=100 and < --samples")
    if args.dt_ms <= 0 or args.duration_ms < 500:
        raise ValueError("Use dt>0 and duration>=500 ms")
    if args.braess_threshold < 1.0:
        raise ValueError("--braess-threshold must be >=1")
    if args.robust_threshold <= args.braess_threshold:
        raise ValueError("--robust-threshold must exceed --braess-threshold")

    if args.threads > 0:
        set_num_threads(args.threads)

    chosen_priors = [item.strip() for item in args.priors.split(",") if item.strip()]
    available_priors = prior_specs()
    unknown = sorted(set(chosen_priors) - set(available_priors))
    if unknown:
        raise ValueError(f"Unknown priors: {unknown}")

    targets, target_source, target_sha = load_targets(args.targets)
    validation = targets["validation"]
    experimental_k = int(validation["responder_like_count"])
    experimental_n = int(validation["responder_like_n"])

    out_dir = args.out.expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "figures").mkdir(exist_ok=True)
    (out_dir / "experimental_targets.json").write_text(
        json.dumps(targets, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    all_full_frames: list[pd.DataFrame] = []
    accepted_frames: list[pd.DataFrame] = []
    sensitivity_frames: list[pd.DataFrame] = []
    summary_records: list[dict[str, Any]] = []
    all_frames_by_prior: dict[str, pd.DataFrame] = {}
    all_parameters_by_prior: dict[str, np.ndarray] = {}
    selections: list[tuple[str, int, str]] = []
    numerical_records: list[dict[str, Any]] = []

    for prior_index, prior_name in enumerate(chosen_priors):
        prior = available_priors[prior_name]
        parameters = latin_hypercube(
            prior, args.samples, args.seed + 1009 * prior_index
        )
        all_parameters_by_prior[prior_name] = parameters
        frame = pd.DataFrame(parameters, columns=PARAMETER_NAMES)
        frame.insert(0, "sample_id", np.arange(args.samples, dtype=int))
        frame.insert(0, "prior", prior_name)

        control_metrics = simulate_ensemble(
            parameters,
            MECHANISMS["control"],
            args.dt_ms,
            args.duration_ms,
            args.pulse_count,
            args.pulse_interval_ms,
        )
        control_frame = metrics_frame(control_metrics, "control")
        frame = pd.concat([frame, control_frame], axis=1)
        score = calibration_score(control_frame, targets)
        frame["calibration_score"] = score

        finite_indices = np.flatnonzero(np.isfinite(score))
        if len(finite_indices) < args.accepted:
            raise RuntimeError(
                f"{prior_name}: only {len(finite_indices)} valid control "
                f"trajectories for {args.accepted} accepted"
            )
        accepted_indices = finite_indices[
            np.argsort(score[finite_indices])[: args.accepted]
        ]
        accepted_mask = np.zeros(args.samples, dtype=bool)
        accepted_mask[accepted_indices] = True
        frame["accepted_control_calibration"] = accepted_mask

        for mechanism in PRIMARY_MECHANISMS:
            ro_metrics = simulate_ensemble(
                parameters,
                MECHANISMS[mechanism],
                args.dt_ms,
                args.duration_ms,
                args.pulse_count,
                args.pulse_interval_ms,
            )
            ro_frame = metrics_frame(ro_metrics, mechanism)
            frame = pd.concat([frame, ro_frame], axis=1)
            frame[f"{mechanism}_valid_pair"] = (
                (frame["control_valid"] > 0.5)
                & (frame[f"{mechanism}_valid"] > 0.5)
            )
            for endpoint in [
                "peak_PO",
                "plateau_PO_140_250",
                "late_PO_200_500",
                "charge_PO_ms",
            ]:
                frame[f"{mechanism}_{endpoint.replace('_PO', '')}_ratio"] = safe_ratio(
                    frame[f"{mechanism}_{endpoint}"].to_numpy(dtype=float),
                    frame[f"control_{endpoint}"].to_numpy(dtype=float),
                )
            # Stable short alias used by plotting/report code.
            frame[f"{mechanism}_plateau_ratio"] = frame[
                f"{mechanism}_plateau_140_250_ratio"
            ]

            summary_records.append(
                summarize_mechanism(
                    frame,
                    prior_name,
                    mechanism,
                    accepted_mask,
                    args.braess_threshold,
                    args.robust_threshold,
                    experimental_k,
                    experimental_n,
                )
            )

        sensitivity_frames.append(parameter_sensitivity(frame, accepted_mask))
        selections.extend(select_examples(frame, accepted_mask, prior_name))
        accepted_frames.append(frame.loc[accepted_mask].copy())
        all_full_frames.append(frame)
        all_frames_by_prior[prior_name] = frame

        # Numerical audit: repeat a deterministic subset at half time step.
        audit_ids = accepted_indices[: min(100, len(accepted_indices))]
        audit_parameters = parameters[audit_ids]
        for mechanism in [
            "control",
            "single_B_entry_attenuation",
            "branch_reroute",
            "state_transfer",
        ]:
            coarse = (
                control_metrics[audit_ids]
                if mechanism == "control"
                else simulate_ensemble(
                    audit_parameters,
                    MECHANISMS[mechanism],
                    args.dt_ms,
                    args.duration_ms,
                    args.pulse_count,
                    args.pulse_interval_ms,
                )
            )
            fine = simulate_ensemble(
                audit_parameters,
                MECHANISMS[mechanism],
                args.dt_ms / 2.0,
                args.duration_ms,
                args.pulse_count,
                args.pulse_interval_ms,
            )
            rel = np.abs(coarse[:, 1] - fine[:, 1]) / np.maximum(
                np.abs(fine[:, 1]), 1e-12
            )
            numerical_records.append(
                {
                    "prior": prior_name,
                    "mechanism": mechanism,
                    "audit_n": len(audit_ids),
                    "dt_coarse_ms": args.dt_ms,
                    "dt_fine_ms": args.dt_ms / 2.0,
                    "plateau_relative_error_median": float(np.nanmedian(rel)),
                    "plateau_relative_error_q95": float(np.nanquantile(rel, 0.95)),
                    "plateau_relative_error_max": float(np.nanmax(rel)),
                    "fine_mass_error_max": float(np.nanmax(fine[:, 5])),
                    "fine_minimum_state": float(np.nanmin(fine[:, 6])),
                }
            )

    full = pd.concat(all_full_frames, ignore_index=True)
    accepted = pd.concat(accepted_frames, ignore_index=True)
    sensitivity = pd.concat(sensitivity_frames, ignore_index=True)
    summary = pd.DataFrame(summary_records)
    numerical = pd.DataFrame(numerical_records)

    traces, flows = make_trace_tables(
        all_frames_by_prior,
        all_parameters_by_prior,
        selections,
        args.dt_ms,
        args.duration_ms,
        args.pulse_count,
        args.pulse_interval_ms,
    )

    exp_lo, exp_hi = clopper_pearson(experimental_k, experimental_n)
    experimental_frequency = pd.DataFrame(
        [
            {
                "source": "experiment_descriptive",
                "k": experimental_k,
                "n": experimental_n,
                "fraction": experimental_k / experimental_n,
                "ci_method": "Clopper-Pearson exact",
                "ci_low": exp_lo,
                "ci_high": exp_hi,
                "pairing_reconstructed": False,
            }
        ]
    )

    full.to_csv(out_dir / "matched_parameter_all_samples.csv", index=False)
    accepted.to_csv(out_dir / "matched_parameter_accepted.csv", index=False)
    summary.to_csv(out_dir / "mechanism_summary.csv", index=False)
    sensitivity.to_csv(out_dir / "parameter_sensitivity.csv", index=False)
    numerical.to_csv(out_dir / "numerical_audit.csv", index=False)
    traces.to_csv(out_dir / "selected_example_traces.csv", index=False)
    flows.to_csv(out_dir / "selected_example_flow_accounting.csv", index=False)
    experimental_frequency.to_csv(
        out_dir / "experimental_frequency.csv", index=False
    )

    run_summary = {
        "pipeline_step": "10_matched_parameter_intrareceptor_rerouting",
        "script_version": SCRIPT_VERSION,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "platform": platform.platform(),
        "numba_threads": get_num_threads(),
        "samples_per_prior": args.samples,
        "accepted_per_prior": args.accepted,
        "priors": chosen_priors,
        "seed": args.seed,
        "dt_ms": args.dt_ms,
        "duration_ms": args.duration_ms,
        "pulse_count": args.pulse_count,
        "pulse_interval_ms": args.pulse_interval_ms,
        "braess_threshold": args.braess_threshold,
        "robust_threshold": args.robust_threshold,
        "target_source": target_source,
        "target_sha256": target_sha,
        "raw_data_provenance": data_provenance(args.data_root),
        "matched_parameter_constraints": {
            "same_kinetic_parameters": True,
            "same_glutamate_forcing": True,
            "same_conductance": True,
            "same_baseline": True,
            "same_initial_condition": True,
            "same_time_grid": True,
            "per_trace_max_normalization": False,
            "synaptic_extrasynaptic_coupling": False,
            "glutamate_competition": False,
            "pairing_reconstructed": False,
        },
        "control_calibration_uses": [
            "early/primary control shape",
            "late/primary control shape",
            "charge/primary control shape",
        ],
        "control_calibration_does_not_use": [
            "Ro25 outcomes",
            "responder-like labels",
            "separate blocked-condition parameters",
            "PPF as a kinetic constraint",
        ],
        "memantine_note": (
            "Memantine is an observation-level block of the single current "
            "component here; its measured residual does not identify internal "
            "transition rates and is therefore reported in targets but not fitted."
        ),
        "model_scope": (
            "topological possibility and prior-sensitive frequency compatibility; "
            "not biochemical proof and not unique parameter fitting"
        ),
    }
    (out_dir / "run_summary.json").write_text(
        json.dumps(run_summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    write_report(out_dir, summary, targets, target_source, run_summary)
    print(f"Matched-parameter rerouting analysis written to: {out_dir}")


if __name__ == "__main__":
    main()
