#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, os, re, sys, zipfile, hashlib, warnings
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.stats import beta
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, balanced_accuracy_score, r2_score, mean_absolute_error
from sklearn.model_selection import StratifiedKFold, KFold, cross_val_predict
from sklearn.ensemble import HistGradientBoostingRegressor

from model_base import PARAMETER_NAMES, r_plateau_batch

VERSION='1.0.1'
STRONG_DEFAULT=1.6359295439505144
G_GRID=np.array([0.10,0.15,0.20,0.25,0.30,0.40,0.50,0.65,0.80,0.95],float)
T_GRID=np.array([3,5,7.5,10,15,20,30,40],float)


def read_table(spec):
    spec=str(spec)
    if '::' in spec:
        z,m=spec.split('::',1)
        with zipfile.ZipFile(z) as Z:
            with Z.open(m) as f: return pd.read_csv(f)
    p=Path(spec)
    if p.suffix=='.parquet': return pd.read_parquet(p)
    if p.suffix=='.gz': return pd.read_csv(p,compression='gzip')
    return pd.read_csv(p)

def normalize_columns(df):
    ren={}
    aliases={
      'prior':['prior','prior_name'], 'sample_id':['sample_id','sample','id','candidate_id'],
      'pulse_amplitude_au':['pulse_amplitude_au','pulse_amplitude','pulse_amp','A_pulse'],
      'glutamate_tau_ms':['glutamate_tau_ms','tau_G_ms','tau_glutamate_ms','glutamate_tau'],
      'calibration_score':['calibration_score','score','calib_score']}
    for target,opts in aliases.items():
        if target not in df.columns:
            for x in opts:
                if x in df.columns: ren[x]=target; break
    return df.rename(columns=ren)

def required_rate_columns(df): return all(c in df.columns for c in PARAMETER_NAMES)

def candidate_roots(extra=None):
    roots=[]
    for x in [extra, os.getcwd(), '/root/nmda2','/root/nmda','/home/vlad/nmda','/home/vlad/nmda2']:
        if x and Path(x).exists():
            p=Path(x).resolve()
            if p not in roots: roots.append(p)
    return roots

def likely_files(roots):
    pats=['*step10*.zip','*step_10*.zip','*step14*.zip','*step_14*.zip','*matched*.csv','*candidate*.csv','*accepted*.csv','*calibration*.csv','*step10*.csv','*step14*.csv']
    out=[]
    for root in roots:
        for pat in pats:
            try:
                for p in root.rglob(pat):
                    if p.is_file() and p.stat().st_size<8_000_000_000: out.append(p)
            except Exception: pass
    # prioritize names
    uniq=[]; seen=set()
    for p in out:
        s=str(p)
        if s not in seen: seen.add(s); uniq.append(p)
    return uniq[:300]

def inspect_sources(roots,outdir):
    rows=[]
    for p in likely_files(roots):
        try:
            if p.suffix.lower()=='.zip':
                with zipfile.ZipFile(p) as Z:
                    for m in Z.namelist():
                        if not m.lower().endswith('.csv'): continue
                        try:
                            with Z.open(m) as f:
                                head=pd.read_csv(f,nrows=3)
                            head=normalize_columns(head)
                            if required_rate_columns(head):
                                rows.append({'spec':f'{p}::{m}','kind':'zip_csv','columns':'|'.join(head.columns)})
                        except Exception: pass
            elif p.suffix.lower() in ['.csv','.gz']:
                try:
                    h=normalize_columns(pd.read_csv(p,nrows=3,compression='infer'))
                    if required_rate_columns(h): rows.append({'spec':str(p),'kind':'csv','columns':'|'.join(h.columns)})
                except Exception: pass
        except Exception: pass
    pd.DataFrame(rows).to_csv(outdir/'00_discovered_parameter_tables.csv',index=False)
    return rows

def choose_tables(discovered,precal_arg,accepted_arg):
    if precal_arg and accepted_arg: return precal_arg,accepted_arg
    metas=[]
    for r in discovered:
        try:
            df=normalize_columns(read_table(r['spec']))
            if 'prior' in df.columns: broad=df[df['prior'].astype(str).str.lower()=='broad']
            else: broad=df
            metas.append((r['spec'],len(df),len(broad),set(df.columns)))
        except Exception: continue
    precal=precal_arg
    accepted=accepted_arg
    if not precal:
        cand=[x for x in metas if x[2]>=49000]
        cand.sort(key=lambda x:(abs(x[2]-50000),0 if 'calibration_score' in x[3] else 1))
        if cand: precal=cand[0][0]
    if not accepted:
        cand=[x for x in metas if 4900<=x[2]<=5100]
        cand.sort(key=lambda x:abs(x[2]-5000))
        if cand: accepted=cand[0][0]
    return precal,accepted

def audit_inputs(pre,acc,outdir):
    pre=normalize_columns(pre.copy()); acc=normalize_columns(acc.copy())
    if not required_rate_columns(pre) or not required_rate_columns(acc): raise RuntimeError('Missing one or more of 12 frozen kinetic-rate columns.')
    if 'prior' in pre.columns: pre=pre[pre.prior.astype(str).str.lower()=='broad'].copy()
    if 'prior' in acc.columns: acc=acc[acc.prior.astype(str).str.lower()=='broad'].copy()
    if len(pre)!=50000: raise RuntimeError(f'Pre-calibration broad table has {len(pre)} rows; expected exactly 50000.')
    if len(acc)!=5000: raise RuntimeError(f'Accepted broad table has {len(acc)} rows; expected exactly 5000.')
    if 'sample_id' not in pre.columns or 'sample_id' not in acc.columns: raise RuntimeError('sample_id is required in both tables.')
    pre['sample_id']=pre.sample_id.astype(int); acc['sample_id']=acc.sample_id.astype(int)
    if pre.sample_id.duplicated().any() or acc.sample_id.duplicated().any(): raise RuntimeError('Duplicate sample_id detected.')
    aid=set(acc.sample_id); pre['accepted']=pre.sample_id.isin(aid)
    if pre.accepted.sum()!=5000: raise RuntimeError(f'Accepted-ID reconstruction gives {pre.accepted.sum()}, expected 5000.')
    if 37318 not in set(pre.sample_id) or 37318 not in aid: raise RuntimeError('Frozen witness sample 37318 is not present and accepted.')
    bad=(pre[list(PARAMETER_NAMES)]<=0).any(axis=1).sum()
    if bad: raise RuntimeError(f'{bad} candidate rows have non-positive kinetic rates; log geometry invalid.')
    audit={'version':VERSION,'precal_broad_n':len(pre),'accepted_broad_n':len(acc),'witness_37318_accepted':True,'rate_columns':list(PARAMETER_NAMES)}
    (outdir/'00_input_audit.json').write_text(json.dumps(audit,indent=2))
    return pre.reset_index(drop=True),acc.reset_index(drop=True)

def full_grid_scan(pre,outdir,strong,dt_screen,batch_size,guard,save_grid):
    P=pre[list(PARAMETER_NAMES)].to_numpy(float)
    n=len(pre); nodes=[(g,t) for g in G_GRID for t in T_GRID]
    R=np.empty((n,len(nodes)),dtype=np.float32)
    node_rows=[]
    for j,(g,tau) in enumerate(nodes):
        col=np.empty(n,float)
        for a in range(0,n,batch_size):
            b=min(n,a+batch_size)
            r,_,_=r_plateau_batch(P[a:b],g,tau,dt_screen)
            col[a:b]=r
        R[:,j]=col.astype(np.float32)
        node_rows.append({'node_index':j,'G_peak':g,'tau_G_ms':tau,'n_valid':int(np.isfinite(col).sum()),'n_braess':int(np.sum(col>1)),'n_strong_screen':int(np.sum(col>=strong)),'max_r_screen':float(np.nanmax(col))})
        print(f'grid {j+1:02d}/80 G={g:g} tau={tau:g}: strong(screen)={np.sum(col>=strong)}',flush=True)

    # Write the expensive screening result BEFORE any confirmation work.
    pd.DataFrame(node_rows).to_csv(outdir/'01_forcing_node_screen_summary.csv',index=False)
    if save_grid:
        np.save(outdir/'02_full_grid_r_screen.npy',R)
    checkpoint={'stage':'screen_complete','n_candidates':int(n),'n_nodes':int(len(nodes)),
                'dt_screen':float(dt_screen),'strong_threshold':float(strong),'guard':float(guard)}
    (outdir/'02A_screen_checkpoint.json').write_text(json.dumps(checkpoint,indent=2))
    print('SCREEN CHECKPOINT WRITTEN',flush=True)

    # dt=0.2 screening is only re-evaluated at dt=0.1 for candidates whose
    # SCREEN MAXIMUM lies inside a +/- guard band around the threshold.
    # Candidates above threshold+guard are already safely strong; candidates
    # below threshold-guard are safely non-strong.  v1.0 incorrectly reran all
    # strong candidates one-by-one over many nodes, creating a pathological
    # multi-hour serial stage after grid 80/80.
    max_screen=np.nanmax(R,axis=1)
    definite_strong=max_screen >= (strong + guard)
    ambiguous=np.where((max_screen >= strong-guard) & (max_screen < strong+guard))[0]
    rmax_final=max_screen.astype(float)
    argmax_final=np.nanargmax(R,axis=1)
    strong_any=definite_strong.copy()
    confirm_rows=[]
    print(f'confirmation band: {len(ambiguous)} candidates; definite strong from screen: {int(definite_strong.sum())}',flush=True)

    # Confirm ambiguous candidates in vectorized node batches rather than one
    # candidate at a time. Each node is simulated once for all ambiguous rows
    # that were within the guard at that node.
    best=np.full(n,-np.inf,float)
    bestj=np.full(n,-1,int)
    amb_mask=np.zeros(n,bool); amb_mask[ambiguous]=True
    for j,(g,tau) in enumerate(nodes):
        idx=np.where(amb_mask & (R[:,j].astype(float) >= strong-guard))[0]
        if len(idx)==0:
            continue
        vals=[]
        for a in range(0,len(idx),batch_size):
            ii=idx[a:a+batch_size]
            rr,_,_=r_plateau_batch(P[ii],g,tau,0.1)
            vals.append(rr)
        rr=np.concatenate(vals) if vals else np.array([],float)
        for ii,v in zip(idx,rr):
            confirm_rows.append({'sample_id':int(pre.iloc[ii].sample_id),'node_index':int(j),
                'G_peak':g,'tau_G_ms':tau,'r_dt0p2':float(R[ii,j]),'r_dt0p1':float(v)})
            if np.isfinite(v) and v>best[ii]:
                best[ii]=float(v); bestj[ii]=int(j)
        print(f'confirm node {j+1:02d}/80 G={g:g} tau={tau:g}: n={len(idx)}',flush=True)

    for idx in ambiguous:
        if bestj[idx]>=0:
            rmax_final[idx]=best[idx]
            argmax_final[idx]=bestj[idx]
            strong_any[idx]=best[idx]>=strong
        else:
            strong_any[idx]=False

    braess_any=np.nanmax(R,axis=1)>1.0
    n_strong_nodes_screen=np.sum(R>=strong,axis=1)
    summary=pre[['sample_id','accepted']].copy()
    summary['r_max_screen_dt0p2']=max_screen
    summary['r_max_confirmed_or_screen']=rmax_final
    summary['argmax_node_index']=argmax_final
    summary['G_peak_at_max']=[nodes[j][0] for j in argmax_final]
    summary['tau_G_ms_at_max']=[nodes[j][1] for j in argmax_final]
    summary['braess_anywhere_screen']=braess_any
    summary['n_strong_nodes_screen']=n_strong_nodes_screen
    summary['strong_anywhere_confirmed']=strong_any
    summary['confirmation_needed']=False
    summary.loc[ambiguous,'confirmation_needed']=True
    summary.to_csv(outdir/'03_candidate_grid_summary.csv',index=False)
    pd.DataFrame(confirm_rows).to_csv(outdir/'03_threshold_confirmations.csv',index=False)
    print(f'CONFIRMATION COMPLETE: strong anywhere={int(strong_any.sum())}/{n}',flush=True)
    return summary,R,nodes

def geometry(pre,summary,outdir):
    X=np.log10(pre[list(PARAMETER_NAMES)].to_numpy(float)); y=summary.strong_anywhere_confirmed.to_numpy(int); acc=pre.accepted.to_numpy(bool)
    sc=StandardScaler(); Z=sc.fit_transform(X)
    pca=PCA(n_components=min(6,Z.shape[1]),random_state=1); PCs=pca.fit_transform(Z)
    geom=pre[['sample_id','accepted']].copy(); geom['strong_anywhere']=y.astype(bool)
    for i in range(PCs.shape[1]): geom[f'PC{i+1}']=PCs[:,i]
    geom.to_csv(outdir/'04_parameter_geometry_scores.csv',index=False)
    # strong classifier, all 50k; provides a smooth correlated direction.
    if y.sum()>=10 and (len(y)-y.sum())>=10:
        cv=StratifiedKFold(5,shuffle=True,random_state=20260910)
        clf=LogisticRegression(max_iter=3000,class_weight='balanced',C=1.0)
        oof=cross_val_predict(clf,Z,y,cv=cv,method='decision_function',n_jobs=1)
        auc=float(roc_auc_score(y,oof)); clf.fit(Z,y); coef=clf.coef_[0]
        smooth_score=clf.decision_function(Z)
    else:
        auc=float('nan'); coef=np.full(Z.shape[1],np.nan); smooth_score=np.zeros(len(y))
    # univariate AUCs, orientation-free
    uni=[]
    for i,name in enumerate(PARAMETER_NAMES):
        if y.sum() and y.sum()<len(y):
            a=roc_auc_score(y,Z[:,i]); a=max(a,1-a)
        else:a=np.nan
        uni.append({'parameter':name,'abs_univariate_auc':a,'multivariate_logistic_coef':coef[i]})
    pd.DataFrame(uni).sort_values('abs_univariate_auc',ascending=False).to_csv(outdir/'05_geometry_rate_importance.csv',index=False)
    # PCA plot four classes
    fig,ax=plt.subplots(figsize=(7.4,6.0))
    cls=[(~acc)&(~y.astype(bool)),(~acc)&(y.astype(bool)),acc&(~y.astype(bool)),acc&(y.astype(bool))]
    labs=['rejected, non-strong','rejected, strong','accepted, non-strong','accepted, strong']
    marks=['.','x','o','*']
    for m,l,mk in zip(cls,labs,marks):
        if m.sum(): ax.scatter(PCs[m,0],PCs[m,1],s=10 if mk=='.' else 24,marker=mk,alpha=.45,label=f'{l} (n={m.sum()})')
    ax.set_xlabel(f'PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)'); ax.set_ylabel(f'PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)'); ax.legend(fontsize=8)
    fig.tight_layout(); fig.savefig(outdir/'Fig18A_parameter_geometry.pdf'); plt.close(fig)
    meta={'strong_all_n':int(y.sum()),'strong_all_fraction':float(y.mean()),'strong_accepted_n':int(np.sum(y&acc)),'strong_accepted_fraction':float(np.mean(y[acc])),'strong_classifier_oof_auc':auc,'pca_explained_variance_ratio':pca.explained_variance_ratio_.tolist()}
    (outdir/'05_geometry_summary.json').write_text(json.dumps(meta,indent=2))
    return Z,smooth_score,meta

def beta_interval(k,n,alpha=.05):
    # Jeffreys interval for descriptive uncertainty only
    lo=float(beta.ppf(alpha/2,k+.5,n-k+.5)); hi=float(beta.ppf(1-alpha/2,k+.5,n-k+.5)); return lo,hi

def tilt_prior(pre,summary,Z,score,outdir,target=5/11):
    a=pre.accepted.to_numpy(bool); y=summary.strong_anywhere_confirmed.to_numpy(int); s=score[a]; ya=y[a]
    n=len(s); k=int(ya.sum()); base=float(ya.mean())
    result={'accepted_n':n,'accepted_strong_anywhere_n':k,'accepted_strong_anywhere_fraction':base,'experimental_target_incidence':target}
    if k==0 or k==n or np.std(s)<1e-12:
        result.update({'status':'not_identifiable_from_accepted_support','reason':'accepted ensemble has no usable strong/non-strong support or smooth score is degenerate'})
        (outdir/'06_prior_reweighting_summary.json').write_text(json.dumps(result,indent=2)); return result,None
    s0=s-np.mean(s)
    def calc(lam):
        q=lam*s0; q-=np.max(q); w=np.exp(q); w/=w.sum(); return w,float(np.sum(w*ya))
    # expand bracket
    f=lambda l:calc(l)[1]-target
    lo,hi=-1.,1.
    for _ in range(30):
        if f(lo)*f(hi)<=0: break
        lo*=2; hi*=2
    if f(lo)*f(hi)>0:
        result.update({'status':'target_not_reachable_with_logistic_score_tilt','reachable_low':calc(lo)[1],'reachable_high':calc(hi)[1]})
        (outdir/'06_prior_reweighting_summary.json').write_text(json.dumps(result,indent=2)); return result,None
    lam=float(brentq(f,lo,hi)); w,ach=calc(lam)
    ess=float(1/np.sum(w*w)); kl=float(np.sum(w*np.log(np.maximum(w*n,1e-300))))
    lo_ci,hi_ci=beta_interval(5,11)
    result.update({'status':'fit','lambda':lam,'achieved_incidence':ach,'effective_sample_size':ess,'ESS_fraction':ess/n,'KL_nats_from_uniform_accepted':kl,'max_weight':float(w.max()),'experimental_Jeffreys_95CI':[lo_ci,hi_ci]})
    # weighted moments in standardized log-rate space
    Za=Z[a]; mu=np.sum(Za*w[:,None],axis=0); centered=Za-mu; cov=(centered*w[:,None]).T@centered
    moments=pd.DataFrame({'parameter':PARAMETER_NAMES,'weighted_z_mean':mu,'unweighted_z_mean':Za.mean(axis=0)})
    moments.to_csv(outdir/'06A_reweighted_parameter_means.csv',index=False)
    pd.DataFrame(cov,index=PARAMETER_NAMES,columns=PARAMETER_NAMES).to_csv(outdir/'06B_reweighted_correlation_structure.csv')
    weights=pre.loc[a,['sample_id']].copy(); weights['strong_anywhere']=ya.astype(bool); weights['smooth_strong_score']=s; weights['weight']=w
    weights.sort_values('weight',ascending=False).to_csv(outdir/'06C_accepted_reweighting_weights.csv',index=False)
    (outdir/'06_prior_reweighting_summary.json').write_text(json.dumps(result,indent=2))
    fig,ax=plt.subplots(figsize=(7,4.6)); ax.bar(['unweighted accepted','experiment','minimum-KL tilt'],[base,target,ach]); ax.set_ylabel('Strong-response incidence'); ax.set_ylim(0,min(1,max(target,ach,base)*1.35+0.02)); ax.text(2,ach,f'ESS={ess:.0f}/{n}\nKL={kl:.2f} nats',ha='center',va='bottom',fontsize=9); fig.tight_layout(); fig.savefig(outdir/'Fig18B_prior_reweighting.pdf'); plt.close(fig)
    return result,w

def calibration_surrogate(pre,Z,outdir):
    if 'calibration_score' not in pre.columns:
        return {'status':'unavailable','reason':'pre-calibration table has no calibration_score'},None,None
    y=pd.to_numeric(pre.calibration_score,errors='coerce').to_numpy(float); ok=np.isfinite(y)
    if ok.sum()<45000: return {'status':'unavailable','reason':'too few finite calibration scores'},None,None
    acc=pre.accepted.to_numpy(bool)
    # infer acceptance direction and threshold directly from historical split
    medA=np.nanmedian(y[acc]); medR=np.nanmedian(y[~acc]); lower_is_better=medA<medR
    maxA=np.nanmax(y[acc]); minA=np.nanmin(y[acc]); minR=np.nanmin(y[~acc]); maxR=np.nanmax(y[~acc])
    cutoff=(maxA+minR)/2 if lower_is_better else (minA+maxR)/2
    # include inherited forcing fields if available
    feats=[Z]
    extras=[]
    for c in ['pulse_amplitude_au','glutamate_tau_ms']:
        if c in pre.columns:
            v=pd.to_numeric(pre[c],errors='coerce').to_numpy(float)
            if np.all(np.isfinite(v)):
                vv=np.log10(v) if np.all(v>0) else v
                vv=(vv-vv.mean())/(vv.std()+1e-12); feats.append(vv[:,None]); extras.append(c)
    X=np.hstack(feats)
    model=HistGradientBoostingRegressor(max_iter=250,learning_rate=.07,max_leaf_nodes=31,l2_regularization=.2,random_state=20260910)
    kf=KFold(5,shuffle=True,random_state=20260910)
    pred=cross_val_predict(model,X,y,cv=kf,n_jobs=1)
    r2=float(r2_score(y,pred)); mae=float(mean_absolute_error(y,pred))
    pred_acc=(pred<=cutoff) if lower_is_better else (pred>=cutoff)
    bal=float(balanced_accuracy_score(acc,pred_acc)); auc=float(roc_auc_score(acc,-pred if lower_is_better else pred))
    model.fit(X,y)
    status='validated' if (auc>=0.995 and bal>=0.97) else 'failed_validation'
    meta={'status':status,'r2_oof':r2,'mae_oof':mae,'acceptance_auc_oof':auc,'acceptance_balanced_accuracy_oof':bal,'lower_score_is_better':bool(lower_is_better),'historical_cutoff':float(cutoff),'accepted_score_median':float(medA),'rejected_score_median':float(medR),'extra_features':extras}
    (outdir/'07_calibration_surrogate_validation.json').write_text(json.dumps(meta,indent=2))
    return meta,(model,X.shape[1]),cutoff

def perturbation_cloud(pre,Z,summary,outdir,cal_meta,model_pack,cutoff,strong,n_per=5000,seed=20260910):
    witness=pre[pre.sample_id==37318].iloc[0]; base=witness[list(PARAMETER_NAMES)].to_numpy(float)
    rng=np.random.default_rng(seed); rows=[]
    if cal_meta.get('status')!='validated' or model_pack is None:
        (outdir/'08_witness_cloud_summary.json').write_text(json.dumps({'status':'skipped','reason':'calibration surrogate not validated'},indent=2)); return
    model,nfeat=model_pack
    # standardized transform reconstructed from whole pre log-rates
    Xlog=np.log10(pre[list(PARAMETER_NAMES)].to_numpy(float)); mu=Xlog.mean(axis=0); sd=Xlog.std(axis=0)
    lower=cal_meta['lower_score_is_better']
    for pct in [2,5,10,20]:
        factors=rng.uniform(1-pct/100,1+pct/100,size=(n_per,12)); P=base[None,:]*factors
        r,_,_=r_plateau_batch(P,0.95,10.0,0.1); isstrong=r>=strong
        Zp=(np.log10(P)-mu)/sd; feat=[Zp]
        for c in cal_meta.get('extra_features',[]):
            train=pd.to_numeric(pre[c],errors='coerce').to_numpy(float); val=float(witness[c]);
            if np.all(train>0): train=np.log10(train); val=np.log10(val)
            val=(val-train.mean())/(train.std()+1e-12); feat.append(np.full((n_per,1),val))
        Xp=np.hstack(feat); score=model.predict(Xp); compat=score<=cutoff if lower else score>=cutoff
        # inside original coordinate-wise log-range
        L=np.log10(P); allL=np.log10(pre[list(PARAMETER_NAMES)].to_numpy(float)); inside=np.all((L>=allL.min(axis=0))&(L<=allL.max(axis=0)),axis=1)
        rows.append({'perturbation_pct':pct,'n':n_per,'strong_fraction':float(isstrong.mean()),'predicted_control_compatible_fraction':float(compat.mean()),'strong_and_predicted_compatible_fraction':float(np.mean(isstrong&compat)),'inside_training_box_fraction':float(inside.mean()),'strong_and_compatible_inside_box_fraction':float(np.mean((isstrong&compat)[inside])) if inside.any() else np.nan,'median_predicted_calibration_score':float(np.median(score))})
    df=pd.DataFrame(rows); df.to_csv(outdir/'08_witness_cloud_summary.csv',index=False)
    (outdir/'08_witness_cloud_summary.json').write_text(df.to_json(orient='records',indent=2))
    fig,ax=plt.subplots(figsize=(7,4.8)); ax.plot(df.perturbation_pct,df.strong_fraction,marker='o',label='strong'); ax.plot(df.perturbation_pct,df.predicted_control_compatible_fraction,marker='o',label='control-compatible (surrogate)'); ax.plot(df.perturbation_pct,df.strong_and_predicted_compatible_fraction,marker='o',label='both'); ax.set_xlabel('Independent rate perturbation (±%)'); ax.set_ylabel('Fraction'); ax.set_ylim(0,1.02); ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(outdir/'Fig18C_witness_compatibility_cloud.pdf'); plt.close(fig)

def final_report(pre,summary,geom,tilt,cal,outdir,strong):
    acc=pre.accepted.to_numpy(bool); y=summary.strong_anywhere_confirmed.to_numpy(bool)
    max_model=float(summary.r_max_confirmed_or_screen.max()); exp=pd.read_csv(Path(__file__).parent/'inputs/experimental_minus40.csv'); max_exp=float(exp.r_plateau.max())
    rep={'strong_threshold':strong,'precal_strong_anywhere_n':int(y.sum()),'precal_strong_anywhere_fraction':float(y.mean()),'accepted_strong_anywhere_n':int(np.sum(y&acc)),'accepted_strong_anywhere_fraction':float(np.mean(y[acc])),'experimental_observed_strong_fraction':5/11,'base_global_max_in_scan':max_model,'experimental_max_ratio':max_exp,'base_can_cover_experimental_max':bool(max_model>=max_exp),'geometry':geom,'prior_reweighting':tilt,'calibration_surrogate':cal}
    if tilt.get('status')=='fit':
        essf=tilt['ESS_fraction']
        if essf>=0.1: dec='correlated_reweighting_reconciles_incidence_without_severe_weight_collapse'
        elif essf>=0.01: dec='reweighting_can_match_incidence_but_requires_concentrated_parameter_measure'
        else: dec='matching_incidence_requires_extreme_concentration_within_current_accepted_support'
    else: dec='current_accepted_support_is_insufficient_to_identify_an_experiment_informed_distribution'
    rep['decision_code']=dec
    (outdir/'09_scientific_decision.json').write_text(json.dumps(rep,indent=2))
    lines=['# Step 18 results','',f'- Strong threshold: {strong:.8f}',f'- Pre-calibration broad sets strong somewhere on 80-node grid: {y.sum()}/{len(y)} ({100*y.mean():.3f}%).',f'- Accepted broad sets strong somewhere: {np.sum(y&acc)}/{acc.sum()} ({100*np.mean(y[acc]):.3f}%).',f'- Experimental sample: 5/11 ({100*5/11:.1f}%) strong at -40 mV.',f'- Base scan maximum: {max_model:.6g}; experimental maximum: {max_exp:.6g}.',f'- Prior-reweighting decision: {dec}.',f"- Calibration surrogate: {cal.get('status','unknown')}.",'', 'Interpretation rule: sampled parameter fractions are not biological probabilities. Step 18 asks whether a structured reweighting of control-compatible kinetic space can reproduce the observed experimental incidence without collapsing onto one or a few parameter sets.']
    (outdir/'README_RESULTS.md').write_text('\n'.join(lines)+'\n')

def self_test():
    rng=np.random.default_rng(1); P=np.exp(rng.normal(-2,0.5,size=(8,12)))
    r,c,b=r_plateau_batch(P,0.5,10,0.2)
    assert len(r)==8 and np.all(np.isfinite(r)) and np.all(c>0)
    print('SELF-TEST PASS')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--precal-table',default=None,help='CSV/CSV.GZ/Parquet or ZIP::member containing 50,000 broad pre-calibration candidates')
    ap.add_argument('--accepted-table',default=None,help='table containing 5,000 accepted broad candidates')
    ap.add_argument('--search-root',default=None)
    ap.add_argument('--output',default='results_step_18_prior_geometry')
    ap.add_argument('--dt-screen',type=float,default=0.2)
    ap.add_argument('--batch-size',type=int,default=5000)
    ap.add_argument('--threshold-guard',type=float,default=0.05)
    ap.add_argument('--strong-threshold',type=float,default=STRONG_DEFAULT)
    ap.add_argument('--cloud-n',type=int,default=5000)
    ap.add_argument('--no-save-grid',action='store_true')
    ap.add_argument('--discover-only',action='store_true')
    ap.add_argument('--self-test',action='store_true')
    args=ap.parse_args()
    if args.self_test: self_test(); return
    out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    roots=candidate_roots(args.search_root); disc=inspect_sources(roots,out)
    pre_spec,acc_spec=choose_tables(disc,args.precal_table,args.accepted_table)
    if args.discover_only:
        print(f'precal candidate: {pre_spec}\naccepted candidate: {acc_spec}'); return
    if not pre_spec or not acc_spec:
        raise RuntimeError('Could not identify both 50,000-row pre-calibration broad table and 5,000-row accepted broad table. Inspect 00_discovered_parameter_tables.csv and rerun with --precal-table and --accepted-table. ZIP members are supported as archive.zip::member.csv.')
    print('Pre-calibration table:',pre_spec,flush=True); print('Accepted table:',acc_spec,flush=True)
    pre,acc=audit_inputs(read_table(pre_spec),read_table(acc_spec),out)
    summary,R,nodes=full_grid_scan(pre,out,args.strong_threshold,args.dt_screen,args.batch_size,args.threshold_guard,not args.no_save_grid)
    # gate against Step14 fixed-node known count at screen/confirmation stage
    j=[i for i,(g,t) in enumerate(nodes) if abs(g-.95)<1e-12 and abs(t-10)<1e-12][0]
    fixed_screen=int(np.sum(R[:,j]>=args.strong_threshold));
    gate={'known_step14_fixed_node_strong':809,'step18_dt0p2_fixed_node_strong':fixed_screen,'note':'Step14 used its historical numerical settings; exact equality is not required at dt=0.2, but large discrepancies indicate wrong inputs/model.'}
    (out/'03A_step14_fixed_node_crosscheck.json').write_text(json.dumps(gate,indent=2))
    Z,score,geom=geometry(pre,summary,out)
    tilt,weights=tilt_prior(pre,summary,Z,score,out,5/11)
    cal_meta,model_pack,cutoff=calibration_surrogate(pre,Z,out)
    perturbation_cloud(pre,Z,summary,out,cal_meta,model_pack,cutoff,args.strong_threshold,args.cloud_n)
    final_report(pre,summary,geom,tilt,cal_meta,out,args.strong_threshold)
    # pack results
    zpath=out.parent/(out.name+'.zip')
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as ZF:
        for p in out.rglob('*'):
            if p.is_file(): ZF.write(p,arcname=f'{out.name}/{p.relative_to(out)}')
    print('DONE:',zpath,flush=True)

if __name__=='__main__': main()
